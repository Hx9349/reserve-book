﻿namespace C_Sharp_Final_Admin
{
    partial class FormAdmin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            label1 = new Label();
            splitContainer1 = new SplitContainer();
            label6 = new Label();
            dgvUBStauts = new DataGridView();
            label5 = new Label();
            btnDelete = new Button();
            txtBookId = new TextBox();
            dgvUsers = new DataGridView();
            label4 = new Label();
            label3 = new Label();
            dgvBooks = new DataGridView();
            btnAddBook = new Button();
            picPreview = new PictureBox();
            cmbCategory = new ComboBox();
            label12 = new Label();
            btnBrowseImage = new Button();
            textBox4 = new TextBox();
            txtYear = new TextBox();
            txtAuthor = new TextBox();
            txtName = new TextBox();
            label18 = new Label();
            label10 = new Label();
            label11 = new Label();
            label9 = new Label();
            label8 = new Label();
            btndel = new Button();
            txtBookSts = new TextBox();
            label7 = new Label();
            btnSend = new Button();
            txtEBookId2 = new TextBox();
            label2 = new Label();
            lstExchangeHistory = new ListBox();
            rtbSummary = new RichTextBox();
            label13 = new Label();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvUBStauts).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvUsers).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvBooks).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picPreview).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label1.Location = new Point(695, 9);
            label1.Name = "label1";
            label1.Size = new Size(105, 20);
            label1.TabIndex = 10;
            label1.Text = "後台書籍管理";
            // 
            // splitContainer1
            // 
            splitContainer1.Location = new Point(1, 54);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.Controls.Add(label6);
            splitContainer1.Panel1.Controls.Add(dgvUBStauts);
            splitContainer1.Panel1.Controls.Add(label5);
            splitContainer1.Panel1.Controls.Add(btnDelete);
            splitContainer1.Panel1.Controls.Add(txtBookId);
            splitContainer1.Panel1.Controls.Add(dgvUsers);
            splitContainer1.Panel1.Controls.Add(label4);
            splitContainer1.Panel1.Controls.Add(label3);
            splitContainer1.Panel1.Controls.Add(dgvBooks);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(label13);
            splitContainer1.Panel2.Controls.Add(rtbSummary);
            splitContainer1.Panel2.Controls.Add(btnAddBook);
            splitContainer1.Panel2.Controls.Add(picPreview);
            splitContainer1.Panel2.Controls.Add(cmbCategory);
            splitContainer1.Panel2.Controls.Add(label12);
            splitContainer1.Panel2.Controls.Add(btnBrowseImage);
            splitContainer1.Panel2.Controls.Add(textBox4);
            splitContainer1.Panel2.Controls.Add(txtYear);
            splitContainer1.Panel2.Controls.Add(txtAuthor);
            splitContainer1.Panel2.Controls.Add(txtName);
            splitContainer1.Panel2.Controls.Add(label18);
            splitContainer1.Panel2.Controls.Add(label10);
            splitContainer1.Panel2.Controls.Add(label11);
            splitContainer1.Panel2.Controls.Add(label9);
            splitContainer1.Panel2.Controls.Add(label8);
            splitContainer1.Panel2.Controls.Add(btndel);
            splitContainer1.Panel2.Controls.Add(txtBookSts);
            splitContainer1.Panel2.Controls.Add(label7);
            splitContainer1.Panel2.Controls.Add(btnSend);
            splitContainer1.Panel2.Controls.Add(txtEBookId2);
            splitContainer1.Panel2.Controls.Add(label2);
            splitContainer1.Panel2.Controls.Add(lstExchangeHistory);
            splitContainer1.Size = new Size(1456, 743);
            splitContainer1.SplitterDistance = 767;
            splitContainer1.TabIndex = 11;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label6.Location = new Point(63, 162);
            label6.Name = "label6";
            label6.Size = new Size(196, 20);
            label6.TabIndex = 101;
            label6.Text = "使用者書籍借閱/預約 資料";
            // 
            // dgvUBStauts
            // 
            dgvUBStauts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgvUBStauts.BackgroundColor = SystemColors.Control;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgvUBStauts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgvUBStauts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dgvUBStauts.DefaultCellStyle = dataGridViewCellStyle2;
            dgvUBStauts.Location = new Point(54, 185);
            dgvUBStauts.Name = "dgvUBStauts";
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dgvUBStauts.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dgvUBStauts.Size = new Size(654, 132);
            dgvUBStauts.TabIndex = 100;
            dgvUBStauts.CellClick += dgvUBStauts_CellClick;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label5.Location = new Point(54, 677);
            label5.Name = "label5";
            label5.Size = new Size(140, 20);
            label5.TabIndex = 99;
            label5.Text = "輸入Id 刪除書籍：";
            // 
            // btnDelete
            // 
            btnDelete.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnDelete.Location = new Point(484, 669);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(58, 36);
            btnDelete.TabIndex = 98;
            btnDelete.Text = "刪除";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click_1;
            // 
            // txtBookId
            // 
            txtBookId.Font = new Font("微軟正黑體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtBookId.Location = new Point(193, 674);
            txtBookId.Name = "txtBookId";
            txtBookId.Size = new Size(275, 29);
            txtBookId.TabIndex = 97;
            // 
            // dgvUsers
            // 
            dgvUsers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgvUsers.BackgroundColor = SystemColors.Control;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = SystemColors.Control;
            dataGridViewCellStyle4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            dgvUsers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dgvUsers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = SystemColors.Window;
            dataGridViewCellStyle5.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            dataGridViewCellStyle5.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.False;
            dgvUsers.DefaultCellStyle = dataGridViewCellStyle5;
            dgvUsers.Location = new Point(54, 39);
            dgvUsers.Name = "dgvUsers";
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = SystemColors.Control;
            dataGridViewCellStyle6.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            dataGridViewCellStyle6.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            dgvUsers.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            dgvUsers.Size = new Size(429, 87);
            dgvUsers.TabIndex = 94;
            dgvUsers.CellClick += dgvUsers_CellClick;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label4.Location = new Point(63, 357);
            label4.Name = "label4";
            label4.Size = new Size(73, 20);
            label4.TabIndex = 96;
            label4.Text = "書籍狀態";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label3.Location = new Point(63, 16);
            label3.Name = "label3";
            label3.Size = new Size(89, 20);
            label3.TabIndex = 95;
            label3.Text = "使用者資料";
            // 
            // dgvBooks
            // 
            dgvBooks.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgvBooks.BackgroundColor = SystemColors.Control;
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = SystemColors.Control;
            dataGridViewCellStyle7.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            dataGridViewCellStyle7.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = DataGridViewTriState.True;
            dgvBooks.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            dgvBooks.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = SystemColors.Window;
            dataGridViewCellStyle8.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            dataGridViewCellStyle8.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.False;
            dgvBooks.DefaultCellStyle = dataGridViewCellStyle8;
            dgvBooks.Location = new Point(54, 380);
            dgvBooks.Name = "dgvBooks";
            dataGridViewCellStyle9.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = SystemColors.Control;
            dataGridViewCellStyle9.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            dataGridViewCellStyle9.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = DataGridViewTriState.True;
            dgvBooks.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            dgvBooks.Size = new Size(679, 263);
            dgvBooks.TabIndex = 93;
            dgvBooks.CellClick += dgvBooks_CellClick;
            // 
            // btnAddBook
            // 
            btnAddBook.BackColor = SystemColors.ActiveCaption;
            btnAddBook.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnAddBook.Location = new Point(410, 673);
            btnAddBook.Name = "btnAddBook";
            btnAddBook.Size = new Size(114, 36);
            btnAddBook.TabIndex = 133;
            btnAddBook.Text = "加入書籍";
            btnAddBook.UseVisualStyleBackColor = false;
            btnAddBook.Click += btnAddBook_Click;
            // 
            // picPreview
            // 
            picPreview.Location = new Point(328, 375);
            picPreview.Name = "picPreview";
            picPreview.Size = new Size(168, 144);
            picPreview.TabIndex = 132;
            picPreview.TabStop = false;
            // 
            // cmbCategory
            // 
            cmbCategory.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            cmbCategory.FormattingEnabled = true;
            cmbCategory.Location = new Point(34, 463);
            cmbCategory.Name = "cmbCategory";
            cmbCategory.Size = new Size(216, 28);
            cmbCategory.TabIndex = 131;
            cmbCategory.Text = "請選擇要放置的書籍類別";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label12.Location = new Point(33, 538);
            label12.Name = "label12";
            label12.Size = new Size(265, 20);
            label12.TabIndex = 130;
            label12.Text = "請選擇想要放置的圖片(jpg,png...)：";
            // 
            // btnBrowseImage
            // 
            btnBrowseImage.BackColor = SystemColors.ActiveBorder;
            btnBrowseImage.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnBrowseImage.Location = new Point(304, 527);
            btnBrowseImage.Name = "btnBrowseImage";
            btnBrowseImage.Size = new Size(230, 42);
            btnBrowseImage.TabIndex = 129;
            btnBrowseImage.Text = "從裝置選擇圖片檔案(jpg,png)";
            btnBrowseImage.UseVisualStyleBackColor = false;
            btnBrowseImage.Click += btnBrowseImage_Click;
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            textBox4.Location = new Point(97, 411);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(133, 28);
            textBox4.TabIndex = 128;
            // 
            // txtYear
            // 
            txtYear.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtYear.Location = new Point(117, 372);
            txtYear.Name = "txtYear";
            txtYear.Size = new Size(133, 28);
            txtYear.TabIndex = 127;
            // 
            // txtAuthor
            // 
            txtAuthor.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtAuthor.Location = new Point(97, 337);
            txtAuthor.Name = "txtAuthor";
            txtAuthor.Size = new Size(133, 28);
            txtAuthor.TabIndex = 126;
            // 
            // txtName
            // 
            txtName.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtName.Location = new Point(208, 303);
            txtName.Name = "txtName";
            txtName.Size = new Size(270, 28);
            txtName.TabIndex = 125;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label18.Location = new Point(34, 414);
            label18.Name = "label18";
            label18.Size = new Size(57, 20);
            label18.TabIndex = 124;
            label18.Text = "編號：";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label10.Location = new Point(33, 375);
            label10.Name = "label10";
            label10.Size = new Size(89, 20);
            label10.TabIndex = 123;
            label10.Text = "出版年分：";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label11.Location = new Point(34, 340);
            label11.Name = "label11";
            label11.Size = new Size(57, 20);
            label11.TabIndex = 122;
            label11.Text = "作者：";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label9.Location = new Point(33, 306);
            label9.Name = "label9";
            label9.Size = new Size(169, 20);
            label9.TabIndex = 121;
            label9.Text = "填寫想要新增的書名：";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label8.Location = new Point(33, 248);
            label8.Name = "label8";
            label8.Size = new Size(169, 20);
            label8.TabIndex = 104;
            label8.Text = "點擊並刪除書籍狀態：";
            // 
            // btndel
            // 
            btndel.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btndel.Location = new Point(410, 240);
            btndel.Name = "btndel";
            btndel.Size = new Size(58, 36);
            btndel.TabIndex = 106;
            btndel.Text = "刪除";
            btndel.UseVisualStyleBackColor = true;
            btndel.Click += btndel_Click;
            // 
            // txtBookSts
            // 
            txtBookSts.Font = new Font("微軟正黑體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtBookSts.Location = new Point(208, 245);
            txtBookSts.Name = "txtBookSts";
            txtBookSts.Size = new Size(196, 29);
            txtBookSts.TabIndex = 105;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label7.Location = new Point(33, 185);
            label7.Name = "label7";
            label7.Size = new Size(211, 20);
            label7.TabIndex = 102;
            label7.Text = "點擊Id 寄送逾期/歸還通知：";
            // 
            // btnSend
            // 
            btnSend.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnSend.Location = new Point(452, 180);
            btnSend.Name = "btnSend";
            btnSend.Size = new Size(58, 36);
            btnSend.TabIndex = 103;
            btnSend.Text = "寄送";
            btnSend.UseVisualStyleBackColor = true;
            btnSend.Click += btnSend_Click;
            // 
            // txtEBookId2
            // 
            txtEBookId2.Font = new Font("微軟正黑體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtEBookId2.Location = new Point(250, 182);
            txtEBookId2.Name = "txtEBookId2";
            txtEBookId2.Size = new Size(196, 29);
            txtEBookId2.TabIndex = 102;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label2.Location = new Point(21, 16);
            label2.Name = "label2";
            label2.Size = new Size(121, 20);
            label2.TabIndex = 94;
            label2.Text = "使用者兌換紀錄";
            // 
            // lstExchangeHistory
            // 
            lstExchangeHistory.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lstExchangeHistory.FormattingEnabled = true;
            lstExchangeHistory.ItemHeight = 20;
            lstExchangeHistory.Location = new Point(21, 39);
            lstExchangeHistory.Name = "lstExchangeHistory";
            lstExchangeHistory.Size = new Size(534, 84);
            lstExchangeHistory.TabIndex = 93;
            // 
            // rtbSummary
            // 
            rtbSummary.Location = new Point(34, 601);
            rtbSummary.Name = "rtbSummary";
            rtbSummary.Size = new Size(333, 108);
            rtbSummary.TabIndex = 134;
            rtbSummary.Text = "";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label13.Location = new Point(34, 578);
            label13.Name = "label13";
            label13.Size = new Size(105, 20);
            label13.TabIndex = 135;
            label13.Text = "請輸入大綱：";
            // 
            // FormAdmin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1344, 802);
            Controls.Add(splitContainer1);
            Controls.Add(label1);
            Name = "FormAdmin";
            Text = "FormAdmin";
            Load += FormAdmin_Load;
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel1.PerformLayout();
            splitContainer1.Panel2.ResumeLayout(false);
            splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvUBStauts).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvUsers).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvBooks).EndInit();
            ((System.ComponentModel.ISupportInitialize)picPreview).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private SplitContainer splitContainer1;
        private Label label2;
        private ListBox lstExchangeHistory;
        private DataGridView dgvUBStauts;
        private Label label5;
        private Button btnDelete;
        private TextBox txtBookId;
        private DataGridView dgvUsers;
        private Label label4;
        private Label label3;
        private DataGridView dgvBooks;
        private Label label6;
        private Button btnSend;
        private TextBox txtEBookId2;
        private Label label7;
        private Label label8;
        private Button btndel;
        private TextBox txtBookSts;
        private Label label18;
        private Label label10;
        private Label label11;
        private Label label9;
        private TextBox textBox4;
        private TextBox txtYear;
        private TextBox txtAuthor;
        private TextBox txtName;
        private Label label12;
        private Button btnBrowseImage;
        private ComboBox cmbCategory;
        private PictureBox picPreview;
        private Button btnAddBook;
        private Label label13;
        private RichTextBox rtbSummary;
    }
}
