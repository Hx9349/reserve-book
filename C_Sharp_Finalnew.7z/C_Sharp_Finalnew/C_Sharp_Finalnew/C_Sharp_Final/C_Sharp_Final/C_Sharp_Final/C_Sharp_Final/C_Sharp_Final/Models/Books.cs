﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_Final.Models
{
    public class Books
    {
        public int Id { get; set; }
        public string BookName { get; set; }
        public string Year { get; set; }
        public string Author { get; set; }
        public string Image { get; set; }
        public bool isBorrowed { get; set; }
        public string Category { get; set; }    // 書籍類別"小說" 或 "漫畫"
        public string Summary { get; set; }    // 書籍大綱
    }
}
