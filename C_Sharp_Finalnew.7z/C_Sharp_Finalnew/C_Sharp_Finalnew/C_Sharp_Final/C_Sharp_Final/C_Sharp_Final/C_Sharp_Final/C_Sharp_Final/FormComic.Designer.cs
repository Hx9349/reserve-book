﻿namespace C_Sharp_Final
{
    partial class FormComic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            comBclass = new ComboBox();
            panel1 = new Panel();
            richTextBox4 = new RichTextBox();
            richTextBox3 = new RichTextBox();
            richTextBox2 = new RichTextBox();
            richTextBox1 = new RichTextBox();
            lblMbID4 = new Label();
            label25 = new Label();
            lblMbID3 = new Label();
            label23 = new Label();
            lblMbID1 = new Label();
            lblMbID2 = new Label();
            label21 = new Label();
            label18 = new Label();
            lblMbAt4 = new Label();
            lblMbY4 = new Label();
            lblMbN4 = new Label();
            lblMbY3 = new Label();
            lblMbAt1 = new Label();
            lblMbY1 = new Label();
            lblMbN3 = new Label();
            lblMbAt3 = new Label();
            lblMbN2 = new Label();
            lblMbAt2 = new Label();
            lblMbY2 = new Label();
            lblMbN1 = new Label();
            btnMb1 = new Button();
            btnMb3 = new Button();
            btnMb4 = new Button();
            btnMb2 = new Button();
            label11 = new Label();
            label12 = new Label();
            label7 = new Label();
            label8 = new Label();
            label5 = new Label();
            label6 = new Label();
            label10 = new Label();
            label9 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            btnMbI2 = new Button();
            btnMbI4 = new Button();
            btnMbI3 = new Button();
            btnMbI1 = new Button();
            label17 = new Label();
            button1 = new Button();
            button2 = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // comBclass
            // 
            comBclass.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comBclass.FormattingEnabled = true;
            comBclass.Items.AddRange(new object[] { "漫畫", "小說" });
            comBclass.Location = new Point(90, 18);
            comBclass.Name = "comBclass";
            comBclass.Size = new Size(141, 28);
            comBclass.TabIndex = 3;
            comBclass.Text = "選擇書籍類別";
            comBclass.SelectedIndexChanged += comBclass_SelectedIndexChanged;
            // 
            // panel1
            // 
            panel1.AutoScroll = true;
            panel1.Controls.Add(richTextBox4);
            panel1.Controls.Add(richTextBox3);
            panel1.Controls.Add(richTextBox2);
            panel1.Controls.Add(richTextBox1);
            panel1.Controls.Add(lblMbID4);
            panel1.Controls.Add(label25);
            panel1.Controls.Add(lblMbID3);
            panel1.Controls.Add(label23);
            panel1.Controls.Add(lblMbID1);
            panel1.Controls.Add(lblMbID2);
            panel1.Controls.Add(label21);
            panel1.Controls.Add(label18);
            panel1.Controls.Add(lblMbAt4);
            panel1.Controls.Add(lblMbY4);
            panel1.Controls.Add(lblMbN4);
            panel1.Controls.Add(lblMbY3);
            panel1.Controls.Add(lblMbAt1);
            panel1.Controls.Add(lblMbY1);
            panel1.Controls.Add(lblMbN3);
            panel1.Controls.Add(lblMbAt3);
            panel1.Controls.Add(lblMbN2);
            panel1.Controls.Add(lblMbAt2);
            panel1.Controls.Add(lblMbY2);
            panel1.Controls.Add(lblMbN1);
            panel1.Controls.Add(btnMb1);
            panel1.Controls.Add(btnMb3);
            panel1.Controls.Add(btnMb4);
            panel1.Controls.Add(btnMb2);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(label12);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(btnMbI2);
            panel1.Controls.Add(btnMbI4);
            panel1.Controls.Add(btnMbI3);
            panel1.Controls.Add(btnMbI1);
            panel1.Location = new Point(12, 55);
            panel1.Name = "panel1";
            panel1.Size = new Size(1116, 648);
            panel1.TabIndex = 4;
            // 
            // richTextBox4
            // 
            richTextBox4.BackColor = SystemColors.Control;
            richTextBox4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            richTextBox4.Location = new Point(581, 469);
            richTextBox4.Name = "richTextBox4";
            richTextBox4.Size = new Size(387, 195);
            richTextBox4.TabIndex = 118;
            richTextBox4.Text = "大綱：在國中時期創下五十次失戀紀錄的著名壞學生─櫻木花道，進入了縣立湘北高中。然而才剛開學不久，他就遇到了一位改變他未來的美少女─赤木晴子，櫻木深深為她著迷，也因為她的鼓勵，而加入了籃球隊…";
            // 
            // richTextBox3
            // 
            richTextBox3.BackColor = SystemColors.Control;
            richTextBox3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            richTextBox3.Location = new Point(40, 469);
            richTextBox3.Name = "richTextBox3";
            richTextBox3.Size = new Size(387, 195);
            richTextBox3.TabIndex = 117;
            richTextBox3.Text = "大綱：蠟筆小新的故事，在已故作者臼井儀人的工作室人員的努力下，重新推出「新蠟筆小新」！故事仍然是由一連串的短故事組成。野原新之助的家人、朋友、老師、鄰居們仍然以一貫的面貌，回應讀者們的期待。媽媽買了新電燈泡回來要求爸爸幫忙更換，原本簡單的工作，在小新的搗蛋下一波三折，最後發現燈泡型號不符，媽媽手滑讓燈泡摔破了。";
            // 
            // richTextBox2
            // 
            richTextBox2.BackColor = SystemColors.Control;
            richTextBox2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            richTextBox2.Location = new Point(581, 131);
            richTextBox2.Name = "richTextBox2";
            richTextBox2.Size = new Size(387, 195);
            richTextBox2.TabIndex = 116;
            richTextBox2.Text = "大綱：一個由巨人所掌控的世界。成為巨人食物的人類築起了巨大高聳的城牆，犧牲通往牆外的自由，換來防止對方的侵略。但是虛有其表的和平卻在足以跨越城牆的大巨人出現之下瓦解，一場絕望的戰爭就此開始。";
            // 
            // richTextBox1
            // 
            richTextBox1.BackColor = SystemColors.Control;
            richTextBox1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            richTextBox1.Location = new Point(38, 131);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(387, 195);
            richTextBox1.TabIndex = 115;
            richTextBox1.Text = "大綱：本作主要敘述一隻來自22世紀的貓型機器人——哆啦A夢，受原本主人野比世修的請託從未來回到現代，幫助他高祖父野比大雄的故事。";
            // 
            // lblMbID4
            // 
            lblMbID4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMbID4.Location = new Point(932, 418);
            lblMbID4.Name = "lblMbID4";
            lblMbID4.Size = new Size(78, 20);
            lblMbID4.TabIndex = 114;
            lblMbID4.Text = "14";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label25.Location = new Point(880, 418);
            label25.Name = "label25";
            label25.Size = new Size(57, 20);
            label25.TabIndex = 113;
            label25.Text = "編號：";
            // 
            // lblMbID3
            // 
            lblMbID3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMbID3.Location = new Point(391, 418);
            lblMbID3.Name = "lblMbID3";
            lblMbID3.Size = new Size(78, 20);
            lblMbID3.TabIndex = 112;
            lblMbID3.Text = "13";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label23.Location = new Point(339, 418);
            label23.Name = "label23";
            label23.Size = new Size(57, 20);
            label23.TabIndex = 111;
            label23.Text = "編號：";
            // 
            // lblMbID1
            // 
            lblMbID1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMbID1.Location = new Point(391, 86);
            lblMbID1.Name = "lblMbID1";
            lblMbID1.Size = new Size(78, 20);
            lblMbID1.TabIndex = 110;
            lblMbID1.Text = "11";
            // 
            // lblMbID2
            // 
            lblMbID2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMbID2.Location = new Point(934, 86);
            lblMbID2.Name = "lblMbID2";
            lblMbID2.Size = new Size(78, 20);
            lblMbID2.TabIndex = 109;
            lblMbID2.Text = "12";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label21.Location = new Point(880, 86);
            label21.Name = "label21";
            label21.Size = new Size(57, 20);
            label21.TabIndex = 108;
            label21.Text = "編號：";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label18.Location = new Point(339, 86);
            label18.Name = "label18";
            label18.Size = new Size(57, 20);
            label18.TabIndex = 106;
            label18.Text = "編號：";
            // 
            // lblMbAt4
            // 
            lblMbAt4.AutoSize = true;
            lblMbAt4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMbAt4.Location = new Point(730, 389);
            lblMbAt4.Name = "lblMbAt4";
            lblMbAt4.Size = new Size(73, 20);
            lblMbAt4.TabIndex = 101;
            lblMbAt4.Text = "井上雄彥";
            // 
            // lblMbY4
            // 
            lblMbY4.AutoSize = true;
            lblMbY4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMbY4.Location = new Point(769, 418);
            lblMbY4.Name = "lblMbY4";
            lblMbY4.Size = new Size(95, 20);
            lblMbY4.TabIndex = 100;
            lblMbY4.Text = "2023/04/14";
            // 
            // lblMbN4
            // 
            lblMbN4.AutoSize = true;
            lblMbN4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMbN4.Location = new Point(730, 363);
            lblMbN4.Name = "lblMbN4";
            lblMbN4.Size = new Size(138, 20);
            lblMbN4.TabIndex = 99;
            lblMbN4.Text = "灌籃高手 完全版 1";
            // 
            // lblMbY3
            // 
            lblMbY3.AutoSize = true;
            lblMbY3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMbY3.Location = new Point(228, 418);
            lblMbY3.Name = "lblMbY3";
            lblMbY3.Size = new Size(95, 20);
            lblMbY3.TabIndex = 98;
            lblMbY3.Text = "2012/07/13";
            // 
            // lblMbAt1
            // 
            lblMbAt1.AutoSize = true;
            lblMbAt1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMbAt1.Location = new Point(189, 57);
            lblMbAt1.Name = "lblMbAt1";
            lblMbAt1.Size = new Size(105, 20);
            lblMbAt1.TabIndex = 97;
            lblMbAt1.Text = "藤子·F·不二雄";
            // 
            // lblMbY1
            // 
            lblMbY1.AutoSize = true;
            lblMbY1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMbY1.Location = new Point(228, 86);
            lblMbY1.Name = "lblMbY1";
            lblMbY1.Size = new Size(95, 20);
            lblMbY1.TabIndex = 96;
            lblMbY1.Text = "2004/12/20";
            // 
            // lblMbN3
            // 
            lblMbN3.AutoSize = true;
            lblMbN3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMbN3.Location = new Point(189, 363);
            lblMbN3.Name = "lblMbN3";
            lblMbN3.Size = new Size(106, 20);
            lblMbN3.TabIndex = 95;
            lblMbN3.Text = "新 蠟筆小新 1";
            // 
            // lblMbAt3
            // 
            lblMbAt3.AutoSize = true;
            lblMbAt3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMbAt3.Location = new Point(189, 389);
            lblMbAt3.Name = "lblMbAt3";
            lblMbAt3.Size = new Size(171, 20);
            lblMbAt3.TabIndex = 94;
            lblMbAt3.Text = " 臼井儀人, UYスタジオ";
            // 
            // lblMbN2
            // 
            lblMbN2.AutoSize = true;
            lblMbN2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMbN2.Location = new Point(730, 31);
            lblMbN2.Name = "lblMbN2";
            lblMbN2.Size = new Size(102, 20);
            lblMbN2.TabIndex = 93;
            lblMbN2.Text = "進擊的巨人 1";
            // 
            // lblMbAt2
            // 
            lblMbAt2.AutoSize = true;
            lblMbAt2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMbAt2.Location = new Point(730, 57);
            lblMbAt2.Name = "lblMbAt2";
            lblMbAt2.Size = new Size(57, 20);
            lblMbAt2.TabIndex = 92;
            lblMbAt2.Text = "諫山創";
            // 
            // lblMbY2
            // 
            lblMbY2.AutoSize = true;
            lblMbY2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMbY2.Location = new Point(769, 86);
            lblMbY2.Name = "lblMbY2";
            lblMbY2.Size = new Size(95, 20);
            lblMbY2.TabIndex = 91;
            lblMbY2.Text = "2011/01/31";
            // 
            // lblMbN1
            // 
            lblMbN1.AutoSize = true;
            lblMbN1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMbN1.Location = new Point(189, 31);
            lblMbN1.Name = "lblMbN1";
            lblMbN1.Size = new Size(81, 20);
            lblMbN1.TabIndex = 90;
            lblMbN1.Text = "哆啦A夢 1";
            // 
            // btnMb1
            // 
            btnMb1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnMb1.Location = new Point(445, 293);
            btnMb1.Name = "btnMb1";
            btnMb1.Size = new Size(99, 33);
            btnMb1.TabIndex = 89;
            btnMb1.Text = "借閱/ 預約";
            btnMb1.UseVisualStyleBackColor = true;
            // 
            // btnMb3
            // 
            btnMb3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnMb3.Location = new Point(445, 631);
            btnMb3.Name = "btnMb3";
            btnMb3.Size = new Size(99, 33);
            btnMb3.TabIndex = 88;
            btnMb3.Text = "借閱/ 預約";
            btnMb3.UseVisualStyleBackColor = true;
            // 
            // btnMb4
            // 
            btnMb4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnMb4.Location = new Point(983, 631);
            btnMb4.Name = "btnMb4";
            btnMb4.Size = new Size(99, 33);
            btnMb4.TabIndex = 87;
            btnMb4.Text = "借閱/ 預約";
            btnMb4.UseVisualStyleBackColor = true;
            // 
            // btnMb2
            // 
            btnMb2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnMb2.Location = new Point(983, 293);
            btnMb2.Name = "btnMb2";
            btnMb2.Size = new Size(99, 33);
            btnMb2.TabIndex = 86;
            btnMb2.Text = "借閱/ 預約";
            btnMb2.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label11.Location = new Point(674, 86);
            label11.Name = "label11";
            label11.Size = new Size(89, 20);
            label11.TabIndex = 81;
            label11.Text = "出版年分：";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label12.Location = new Point(674, 57);
            label12.Name = "label12";
            label12.Size = new Size(57, 20);
            label12.TabIndex = 80;
            label12.Text = "作者：";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label7.Location = new Point(133, 418);
            label7.Name = "label7";
            label7.Size = new Size(89, 20);
            label7.TabIndex = 79;
            label7.Text = "出版年分：";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label8.Location = new Point(133, 389);
            label8.Name = "label8";
            label8.Size = new Size(57, 20);
            label8.TabIndex = 78;
            label8.Text = "作者：";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label5.Location = new Point(674, 418);
            label5.Name = "label5";
            label5.Size = new Size(89, 20);
            label5.TabIndex = 77;
            label5.Text = "出版年分：";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label6.Location = new Point(674, 389);
            label6.Name = "label6";
            label6.Size = new Size(57, 20);
            label6.TabIndex = 76;
            label6.Text = "作者：";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label10.Location = new Point(133, 86);
            label10.Name = "label10";
            label10.Size = new Size(89, 20);
            label10.TabIndex = 75;
            label10.Text = "出版年分：";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label9.Location = new Point(133, 57);
            label9.Name = "label9";
            label9.Size = new Size(57, 20);
            label9.TabIndex = 74;
            label9.Text = "作者：";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label4.Location = new Point(674, 363);
            label4.Name = "label4";
            label4.Size = new Size(57, 20);
            label4.TabIndex = 73;
            label4.Text = "書名：";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label3.Location = new Point(133, 363);
            label3.Name = "label3";
            label3.Size = new Size(57, 20);
            label3.TabIndex = 72;
            label3.Text = "書名：";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label2.Location = new Point(674, 31);
            label2.Name = "label2";
            label2.Size = new Size(57, 20);
            label2.TabIndex = 71;
            label2.Text = "書名：";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label1.Location = new Point(133, 31);
            label1.Name = "label1";
            label1.Size = new Size(57, 20);
            label1.TabIndex = 70;
            label1.Text = "書名：";
            // 
            // btnMbI2
            // 
            btnMbI2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnMbI2.Location = new Point(581, 17);
            btnMbI2.Name = "btnMbI2";
            btnMbI2.Size = new Size(87, 100);
            btnMbI2.TabIndex = 69;
            btnMbI2.Text = "b2(書封照片)";
            btnMbI2.UseVisualStyleBackColor = true;
            // 
            // btnMbI4
            // 
            btnMbI4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnMbI4.Location = new Point(581, 349);
            btnMbI4.Name = "btnMbI4";
            btnMbI4.Size = new Size(87, 100);
            btnMbI4.TabIndex = 68;
            btnMbI4.Text = "b4(書封照片)";
            btnMbI4.UseVisualStyleBackColor = true;
            // 
            // btnMbI3
            // 
            btnMbI3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnMbI3.Location = new Point(40, 349);
            btnMbI3.Name = "btnMbI3";
            btnMbI3.Size = new Size(87, 100);
            btnMbI3.TabIndex = 67;
            btnMbI3.Text = "b3(書封照片)";
            btnMbI3.UseVisualStyleBackColor = true;
            // 
            // btnMbI1
            // 
            btnMbI1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnMbI1.Location = new Point(38, 17);
            btnMbI1.Name = "btnMbI1";
            btnMbI1.Size = new Size(87, 100);
            btnMbI1.TabIndex = 66;
            btnMbI1.Text = "b1(書封照片)";
            btnMbI1.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 178);
            label17.Location = new Point(36, 19);
            label17.Name = "label17";
            label17.Size = new Size(48, 22);
            label17.TabIndex = 5;
            label17.Text = "漫畫";
            // 
            // button1
            // 
            button1.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(880, 13);
            button1.Name = "button1";
            button1.Size = new Size(69, 36);
            button1.TabIndex = 72;
            button1.Text = "首頁";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(955, 13);
            button2.Name = "button2";
            button2.Size = new Size(123, 36);
            button2.TabIndex = 71;
            button2.Text = "我的借閱紀錄";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // FormComic
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1131, 718);
            Controls.Add(button1);
            Controls.Add(button2);
            Controls.Add(label17);
            Controls.Add(panel1);
            Controls.Add(comBclass);
            Name = "FormComic";
            Text = "FormComic";
            Load += FormComic_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private ComboBox comBclass;
        private Panel panel1;
        private Label lblMbAt4;
        private Label lblMbY4;
        private Label lblMbN4;
        private Label lblMbY3;
        private Label lblMbAt1;
        private Label lblMbY1;
        private Label lblMbN3;
        private Label lblMbAt3;
        private Label lblMbN2;
        private Label lblMbAt2;
        private Label lblMbY2;
        private Label lblMbN1;
        private Button btnMb1;
        private Button btnMb3;
        private Button btnMb4;
        private Button btnMb2;
        private Label label11;
        private Label label12;
        private Label label7;
        private Label label8;
        private Label label5;
        private Label label6;
        private Label label10;
        private Label label9;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        public Button btnMbI2;
        public Button btnMbI4;
        public Button btnMbI3;
        public Button btnMbI1;
        private Label label17;
        private Label label18;
        private Label lblMbID4;
        private Label label25;
        private Label lblMbID3;
        private Label label23;
        private Label lblMbID1;
        private Label lblMbID2;
        private Label label21;
        private RichTextBox richTextBox1;
        private RichTextBox richTextBox3;
        private RichTextBox richTextBox2;
        private RichTextBox richTextBox4;
        private Button button1;
        private Button button2;
    }
}