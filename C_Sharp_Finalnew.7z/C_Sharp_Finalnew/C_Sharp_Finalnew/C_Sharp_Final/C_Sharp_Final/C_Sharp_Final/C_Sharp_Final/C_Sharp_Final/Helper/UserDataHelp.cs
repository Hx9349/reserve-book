﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Xml;
using C_Sharp_Final.Models;
using C_Sharp_Final.Helper;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace C_Sharp_Final.Helper
{
    public class UserDataHelp
    {
        private static string recordFilePath = JsonPathHelper.GetUserPath();

        // 載入所有使用者資料（含借閱與預約）
        public static List<UserData> LoadUserData()
        {
            if (!File.Exists(recordFilePath)) return new List<UserData>();
            var json = File.ReadAllText(recordFilePath);
            return JsonSerializer.Deserialize<List<UserData>>(json) ?? new List<UserData>();
        }

        // 儲存所有使用者資料
        public static void SaveUserData(List<UserData> users)
        {
            var json = JsonSerializer.Serialize(users, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(recordFilePath, json);
        }

        // 新增紀錄
        public static void AddRecord(string name, string phone, string email, RecordItem newRecord, int pointsToAdd = 10)
        {
            var users = LoadUserData();
            var user = users.FirstOrDefault(u => u.email.Equals(email, StringComparison.OrdinalIgnoreCase));

            if (user == null)
            {
                user = new UserData
                {
                    email = email,
                    name = name,
                    phone = phone,
                    points = 0
                };
                users.Add(user);
            }
            else
            {
                // 若帳號已存在，則更新姓名與電話
                user.name = name;
                user.phone = phone;
            }
            user.points += pointsToAdd;
            user.records.Add(newRecord);
            
            SaveUserData(users);
        }
    }
}