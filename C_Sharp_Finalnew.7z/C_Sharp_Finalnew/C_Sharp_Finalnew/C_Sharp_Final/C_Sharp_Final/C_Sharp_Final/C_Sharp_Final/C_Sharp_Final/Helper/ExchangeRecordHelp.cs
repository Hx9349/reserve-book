﻿using C_Sharp_Final.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using C_Sharp_Final.Helper;

namespace C_Sharp_Final.Helper
{
    public class ExchangeRecordHelp
    {
        private static string recordFilePath = JsonPathHelper.GetExchangePath();

        public static List<ExchangeRecord> LoadProintRecords()
        {
            if (!File.Exists(recordFilePath))
                return new List<ExchangeRecord>();

            string json = File.ReadAllText(recordFilePath);
            return JsonSerializer.Deserialize<List<ExchangeRecord>>(json) ?? new List<ExchangeRecord>();
        }

        public static void SaveProintRecords(List<ExchangeRecord> records)
        {
            string json = JsonSerializer.Serialize(records, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(recordFilePath, json);
        }

        public static void AddProintRecord(ExchangeRecord newRecord)
        {
            var records = LoadProintRecords();
            records.Add(newRecord);
            SaveProintRecords(records);
        }
    }
}
