﻿using System.IO;
using System.Windows.Forms;
using C_Sharp_Final.Helper;

namespace C_Sharp_Final.Helper
{
    public static class JsonPathHelper
    {
        private static string sharedFolder = @"D:\C_Sharp_Finalnew\C_Sharp_Finalnew\C_Sharp_Final\C_Sharp_Final\C_Sharp_Final\C_Sharp_Final\SharedData";
        public static string GetBookPath()
        {
            return Path.Combine(sharedFolder, "books.json");
        }

        public static string GetUserPath()
        {
            return Path.Combine(sharedFolder, "User_Records.json");
        }
            
        public static string GetExchangePath()
        {
            return Path.Combine(sharedFolder, "exchange_records.json");
        }
    }
}
