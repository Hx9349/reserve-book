﻿using C_Sharp_Final.Models;
using Microsoft.VisualBasic.ApplicationServices;
using C_Sharp_Final.Helper;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;
using System.Text;

namespace C_Sharp_Final_Admin
{
    public partial class FormAdmin : Form
    {
        private List<Books> books;
        private List<UserData> usersData;
        private List<ExchangeRecord> exchangeRecords;
        private string currentUserEmail = "";

        public FormAdmin()
        {
            InitializeComponent();
        }
        private void FormAdmin_Load(object sender, EventArgs e)
        {
            LoadAllData();
            CheckDueReminders();
        }
        private void LoadAllData()
        {
            LoadBooks();
            LoadUsers();
            LoadExchangeRecords();
        }
        private void LoadBooks()
        {
            string path = JsonPathHelper.GetBookPath();

            if (File.Exists(path))
            {
                books = BookDataHelp.Loadbooks(); // 自訂 Helper 載入

                MessageBox.Show($"載入書籍筆數：{books.Count}"); // 這可以幫你確定資料真的有被載入

                dgvBooks.Rows.Clear();
                dgvBooks.Columns.Clear();

                dgvBooks.Columns.Add("bookId", "書籍 ID");
                dgvBooks.Columns.Add("title", "書名");
                dgvBooks.Columns.Add("author", "作者");
                dgvBooks.Columns.Add("year", "出版年");
                dgvBooks.Columns.Add("isAvailable", "可借閱");

                foreach (var book in books)
                {
                    dgvBooks.Rows.Add(book.Id, book.BookName, book.Author, book.Year, book.isBorrowed ? "否" : "是");
                }
            }
            else
            {
                MessageBox.Show(JsonPathHelper.GetBookPath());     // 書籍路徑
                MessageBox.Show(JsonPathHelper.GetUserPath());     // 使用者紀錄路徑
                MessageBox.Show(JsonPathHelper.GetExchangePath());
            }
        }

        private void LoadUsers()
        {
            string path = JsonPathHelper.GetUserPath();
            if (File.Exists(path))
            {
                usersData = UserDataHelp.LoadUserData();

                dgvUsers.Columns.Clear();

                dgvUsers.Columns.Add("name", "姓名");
                dgvUsers.Columns.Add("email", "Email");
                dgvUsers.Columns.Add("phone", "電話");
                dgvUsers.Columns.Add("points", "點數");

                foreach (var user in usersData)
                {
                    dgvUsers.Rows.Add(user.name, user.email, user.phone, user.points);
                }
            }
        }

        private void LoadExchangeRecords()
        {
            string path = JsonPathHelper.GetExchangePath();
            if (File.Exists(path))
            {
                exchangeRecords = ExchangeRecordHelp.LoadProintRecords();
                lstExchangeHistory.Items.Clear();
                foreach (var record in exchangeRecords)
                {
                    string item = $"{record.date} - {record.userName} ({record.userEmail}) 兌換了 {record.prize}";
                    lstExchangeHistory.Items.Add(item);
                }
            }
        }
        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            var result = MessageBox.Show("確認刪除書籍？", "確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result != DialogResult.Yes)
                return;

            int bookId;
            if (int.TryParse(txtBookId.Text, out bookId))
            {
                books = BookDataHelp.Loadbooks();
                var bookToRemove = books.FirstOrDefault(b => b.Id == bookId);
                if (bookToRemove != null)
                {
                    books.Remove(bookToRemove);
                    BookDataHelp.SaveBooks(books);
                    MessageBox.Show("刪除成功");
                    LoadBooks(); // 重新載入顯示
                }
                else
                {
                    MessageBox.Show("找不到該書籍");
                }
            }
            else
            {
                MessageBox.Show("請輸入有效的書籍 ID");
            }
        }
        private void dgvUsers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string selectedEmail = dgvUsers.Rows[e.RowIndex].Cells["email"].Value.ToString();

                var selectedUser = usersData.FirstOrDefault(u => u.email == selectedEmail);

                if (selectedUser != null && selectedUser.records != null)
                {
                    dgvUBStauts.Columns.Clear();
                    dgvUBStauts.Rows.Clear();
                    
                    dgvUBStauts.Columns.Add("bookId", "書籍 ID");
                    dgvUBStauts.Columns.Add("title", "書名"); 
                    dgvUBStauts.Columns.Add("status", "狀態");
                    dgvUBStauts.Columns.Add("date", "日期");
                    dgvUBStauts.Columns.Add("dueDate", "到期時間");
                    foreach (var record in selectedUser.records)
                    {
                        // 解析日期並計算到期日（假設借書日格式為 yyyy/MM/dd）
                        DateTime borrowDate;
                        string dueDateStr = "";

                        if (DateTime.TryParse(record.date, out borrowDate))
                        {
                            DateTime dueDate = borrowDate.AddDays(14);
                            dueDateStr = dueDate.ToString("yyyy/MM/dd");
                        }

                        // 顯示到 DataGridView
                        dgvUBStauts.Rows.Add(record.bookId, record.title, record.status, record.date, dueDateStr);
                    }
                }

                currentUserEmail = selectedUser.email;
            }
        }



        private void CheckDueReminders()
        {
            usersData = UserDataHelp.LoadUserData(); // 讀取所有使用者

            foreach (var user in usersData)
            {
                foreach (var record in user.records.Where(r => r.status == "借閱中" && !string.IsNullOrWhiteSpace(r.dueDate)))
                {
                    if (DateTime.TryParse(record.dueDate, out DateTime dueDate))
                    {
                        DateTime today = DateTime.Today;
                        int daysLeft = (dueDate - today).Days;

                        if (daysLeft == 2)
                        {
                            AdminSendEmail(user.email, "歸還提醒", user.name, user.phone, new Books { BookName = record.title });
                        }
                        else if (daysLeft < 0)
                        {
                            AdminSendEmail(user.email, "逾期通知", user.name, user.phone, new Books { BookName = record.title });
                        }
                    }
                }
            }
        }

        private void AdminSendEmail(string email, string subject, string userName, string phone, Books book)
        {
            try
            {
                MailMessage mail = new MailMessage();
                mail.From = new MailAddress("from@example.com");
                mail.To.Add(email);
                mail.Subject = "佐米租書及預約";
                mail.SubjectEncoding = Encoding.UTF8;
                mail.BodyEncoding = Encoding.UTF8;
                string body = "";
                if (subject == "歸還提醒")
                {
                    body = $"親愛的 {userName} 您好，\n\n您所借閱的《{book.BookName}》即將到期（剩下2天），請記得歸還。" +
                        $"\n如果已經歸還，無須理會此訊息。\n\n謝謝您使用本系統！";
                }
                else if (subject == "逾期通知")
                {
                    body = $"親愛的 {userName} 您好，\n\n您所借閱的《{book.BookName}》已經逾期，請盡快歸還。" +
                        $"\n如果已經歸還，無須理會此訊息。\n\n謝謝您使用本系統！";
                }

                mail.Body = body;

                using (SmtpClient smtp = new SmtpClient("sandbox.smtp.mailtrap.io", 2525))
                {
                    smtp.Credentials = new NetworkCredential("bff03953365917", "6a4e4061fbb7e4");
                    smtp.EnableSsl = true;
                    smtp.Send(mail);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"失敗，請填寫正確資料\n{ex.Message}");
            }
        }
        private void btnSend_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtEBookId2.Text))
            {
                MessageBox.Show("請先從書籍列表中選擇一筆書籍，顯示其 ID。");
                return;
            }

            if (string.IsNullOrWhiteSpace(currentUserEmail))
            {
                MessageBox.Show("請先從使用者列表中選擇一位使用者。");
                return;
            }

            if (!int.TryParse(txtEBookId2.Text, out int bookId))
            {
                MessageBox.Show("書籍 ID 格式錯誤。");
                return;
            }

            var selectedBook = books.FirstOrDefault(b => b.Id == bookId);
            if (selectedBook == null)
            {
                MessageBox.Show("找不到對應的書籍。");
                return;
            }

            var selectedUser = usersData.FirstOrDefault(u => u.email == currentUserEmail);
            if (selectedUser == null)
            {
                MessageBox.Show("找不到使用者資訊。");
                return;
            }

            AdminSendEmail(selectedUser.email, "歸還提醒", selectedUser.name, selectedUser.phone, selectedBook);
            MessageBox.Show("通知信已送出！");
        }

        private void dgvBooks_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // 假設書籍的 ID 欄位名稱是 "bookId"
                string bookId = dgvBooks.Rows[e.RowIndex].Cells["bookId"].Value.ToString();
                txtEBookId2.Text = bookId;
            }
        }

    }
}
