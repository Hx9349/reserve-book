﻿namespace C_Sharp_Final
{
    partial class FormReturn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            lblBY = new Label();
            lblBArt = new Label();
            label10 = new Label();
            label11 = new Label();
            lblBN = new Label();
            label8 = new Label();
            txtBookId = new TextBox();
            label4 = new Label();
            label14 = new Label();
            btnconfrim = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            lblUserName = new Label();
            lblPhone = new Label();
            lblEmail = new Label();
            SuspendLayout();
            // 
            // button3
            // 
            button3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            button3.Location = new Point(275, 462);
            button3.Name = "button3";
            button3.Size = new Size(118, 36);
            button3.TabIndex = 55;
            button3.Text = "我的借閱紀錄";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            button2.Location = new Point(55, 462);
            button2.Name = "button2";
            button2.Size = new Size(89, 36);
            button2.TabIndex = 54;
            button2.Text = "取消歸還";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            button1.Location = new Point(150, 462);
            button1.Name = "button1";
            button1.Size = new Size(89, 36);
            button1.TabIndex = 53;
            button1.Text = "確認歸還";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // lblBY
            // 
            lblBY.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblBY.Location = new Point(137, 386);
            lblBY.Name = "lblBY";
            lblBY.Size = new Size(167, 20);
            lblBY.TabIndex = 52;
            // 
            // lblBArt
            // 
            lblBArt.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblBArt.Location = new Point(104, 357);
            lblBArt.Name = "lblBArt";
            lblBArt.Size = new Size(260, 20);
            lblBArt.TabIndex = 51;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label10.Location = new Point(51, 386);
            label10.Name = "label10";
            label10.Size = new Size(89, 20);
            label10.TabIndex = 50;
            label10.Text = "出版年分：";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label11.Location = new Point(51, 357);
            label11.Name = "label11";
            label11.Size = new Size(57, 20);
            label11.TabIndex = 49;
            label11.Text = "作者：";
            // 
            // lblBN
            // 
            lblBN.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblBN.Location = new Point(178, 323);
            lblBN.Name = "lblBN";
            lblBN.Size = new Size(255, 20);
            lblBN.TabIndex = 48;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label8.Location = new Point(51, 323);
            label8.Name = "label8";
            label8.Size = new Size(121, 20);
            label8.TabIndex = 47;
            label8.Text = "你借閱的書名：";
            // 
            // txtBookId
            // 
            txtBookId.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtBookId.Location = new Point(211, 63);
            txtBookId.Name = "txtBookId";
            txtBookId.Size = new Size(212, 28);
            txtBookId.TabIndex = 46;
            txtBookId.TextChanged += txtBookId_TextChanged;
            txtBookId.KeyDown += txtBookId_KeyDown;
            txtBookId.KeyPress += txtBookId_KeyPress;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label4.Location = new Point(49, 66);
            label4.Name = "label4";
            label4.Size = new Size(169, 20);
            label4.TabIndex = 45;
            label4.Text = "請輸入要還書的編號：";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label14.Location = new Point(51, 128);
            label14.Name = "label14";
            label14.Size = new Size(153, 20);
            label14.TabIndex = 44;
            label14.Text = "顯示您的基本資料：";
            // 
            // btnconfrim
            // 
            btnconfrim.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnconfrim.Location = new Point(444, 60);
            btnconfrim.Name = "btnconfrim";
            btnconfrim.Size = new Size(68, 33);
            btnconfrim.TabIndex = 56;
            btnconfrim.Text = "確認";
            btnconfrim.UseVisualStyleBackColor = true;
            btnconfrim.Click += Botton4_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label3.Location = new Point(49, 249);
            label3.Name = "label3";
            label3.Size = new Size(66, 20);
            label3.TabIndex = 59;
            label3.Text = "Email：";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label2.Location = new Point(51, 208);
            label2.Name = "label2";
            label2.Size = new Size(57, 20);
            label2.TabIndex = 58;
            label2.Text = "電話：";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label1.Location = new Point(51, 168);
            label1.Name = "label1";
            label1.Size = new Size(57, 20);
            label1.TabIndex = 57;
            label1.Text = "姓名：";
            // 
            // lblUserName
            // 
            lblUserName.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblUserName.Location = new Point(104, 168);
            lblUserName.Name = "lblUserName";
            lblUserName.Size = new Size(146, 20);
            lblUserName.TabIndex = 62;
            // 
            // lblPhone
            // 
            lblPhone.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblPhone.Location = new Point(104, 208);
            lblPhone.Name = "lblPhone";
            lblPhone.Size = new Size(213, 20);
            lblPhone.TabIndex = 63;
            // 
            // lblEmail
            // 
            lblEmail.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblEmail.Location = new Point(114, 249);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(230, 20);
            lblEmail.TabIndex = 64;
            // 
            // FormReturn
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(768, 557);
            Controls.Add(lblEmail);
            Controls.Add(lblPhone);
            Controls.Add(lblUserName);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnconfrim);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(lblBY);
            Controls.Add(lblBArt);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(lblBN);
            Controls.Add(label8);
            Controls.Add(txtBookId);
            Controls.Add(label4);
            Controls.Add(label14);
            Name = "FormReturn";
            Text = "             ";
            Load += FormReturn_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button3;
        private Button button2;
        private Button button1;
        private Label lblBY;
        private Label lblBArt;
        private Label label10;
        private Label label11;
        private Label lblBN;
        private Label label8;
        private TextBox txtBookId;
        private Label label4;
        private Label label14;
        private Button btnconfrim;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label lblUserName;
        private Label lblPhone;
        private Label lblEmail;
    }
}