﻿using C_Sharp_Final.Helper;
using C_Sharp_Final.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Reflection.Metadata.BlobBuilder;
using C_Sharp_Final.Models;
using C_Sharp_Final.Helper;

namespace C_Sharp_Final
{
    public partial class FormNovel : Form
    {
        private FormScaler scaler;
        private FormBorrow borrowForm;
        private List<Books> books;
        public FormNovel()
        {
            InitializeComponent();
            scaler = new FormScaler(this);
        }
        private void comBclass_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectNbMbform = comBclass.SelectedItem.ToString();
            switch (selectNbMbform)
            {
                case "漫畫":
                    FormComic mbpage = new FormComic();
                    mbpage.Show();
                    this.Hide();
                    break;
                case "小說":
                    FormNovel nbpage = new FormNovel();
                    nbpage.Show();
                    this.Hide();
                    break;
            }
        }
        private void FormNovel_Load(object sender, EventArgs e)
        {
            List<(Button btn, int id)> btnPairs = new List<(Button, int)>
            {
                (btnNb1, 21), (btnNb2, 22), (btnNb3, 23), (btnNb4, 24)
            };
            foreach (var (btn, id) in btnPairs)
            {
                btn.Tag = id;
                btn.Click += HandleBookButtonClick;
            }
            books = BookDataHelp.Loadbooks();

            foreach (var book in books)
            {
                // 透過 Id 或書名找對應的按鈕
                Button btn = GetBtnImageByBookId(book.Id); 

                if (btn != null)
                {
                    btn.Text = "";
                    Image img = Image.FromFile(book.Image);
                    if (book.isBorrowed == true)
                    {
                        btn.Image = FormBorrow.BookImageCray((Bitmap)img); // 將圖轉為灰階
                    }
                    else
                        btn.Image = img; // 顯示原圖
                    btn.ImageAlign = ContentAlignment.MiddleCenter; //對齊圖片
                }
            }
        }
        private void HandleBookButtonClick(object sender, EventArgs e)
        {
            Button btn = sender as Button;

            if (btn?.Tag == null) return;

            int bookId = Convert.ToInt32(btn.Tag);
            var book = books.FirstOrDefault(b => b.Id == bookId);

            if (book == null)
            {
                MessageBox.Show("找不到此書籍資料。");
                return;
            }

            if (book.isBorrowed == true)
            {// 書本按鈕點擊處理：判斷是否已借出。
                DialogResult result = MessageBox.Show(
                    "這本書已被借出，是否前往預約？",
                    "已借出",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Information);

                if (result == DialogResult.No)
                    return;
            }
            if (borrowForm == null || borrowForm.IsDisposed)
                borrowForm = new FormBorrow();

            borrowForm.SetBookInfo(book);
            borrowForm.Show();
            this.Hide(); // 隱藏當前表單
        }
        private Button GetBtnImageByBookId(int bookId)
        {
            return bookId switch
            {
                21 => btnNbI1,
                22 => btnNbI2,
                23 => btnNbI3,
                24 => btnNbI4,
                _ => null
            };
        }
        private void button1_Click(object sender, EventArgs e)
        {
            FrontPage frontPage = new FrontPage();
            frontPage.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormHistory formHistory = new FormHistory();
            formHistory.Show();
            this.Hide();
        }
    }
}
