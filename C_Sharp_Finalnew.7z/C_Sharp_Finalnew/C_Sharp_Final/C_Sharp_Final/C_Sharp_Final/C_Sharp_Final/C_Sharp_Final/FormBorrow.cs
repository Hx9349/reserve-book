﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;
using C_Sharp_Final.Models;
using C_Sharp_Final.Helper;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Text.RegularExpressions;

namespace C_Sharp_Final
{
    public partial class FormBorrow : Form
    {
        private FormScaler scaler;
        private List<Books> books;
        FrontPage frontPage = new FrontPage();
        public FormBorrow()
        {
            InitializeComponent();
            scaler = new FormScaler(this);
        }
        public void SetBookInfo(Books book)
        {
            label17.Text = book.BookName;
            label12.Text = book.Author;
            label13.Text = book.Year;
            label19.Text = book.Id.ToString();
        }
        private void button3_Click(object sender, EventArgs e) //取消借閱按鈕
        {
            FormComic form2 = new FormComic();
            form2.Show();
            this.Close();
        }
        private void UpdateBookImages()
        {
            books = BookDataHelp.Loadbooks();

            var bookButtonMap = new Dictionary<int, Button>
            {//照片配置
                { 11, new FormComic().btnMbI1 },
                { 12, new FormComic().btnMbI2 },
                { 13, new FormComic().btnMbI3 },
                { 14, new FormComic().btnMbI4 },
                { 21, new FormNovel().btnNbI1 },
                { 22, new FormNovel().btnNbI2 },
                { 23, new FormNovel().btnNbI3 },
                { 24, new FormNovel().btnNbI4 },
            };
        }
        public static Bitmap BookImageCray(Bitmap original)
        {//將照片變灰色
            Bitmap newBitmap = new Bitmap(original.Width, original.Height);

            for (int y = 0; y < original.Height; y++)
                for (int x = 0; x < original.Width; x++)
                {
                    Color originalcolor = original.GetPixel(x, y);

                    int grayScale = (int)((originalcolor.R * 0.3) + (originalcolor.G * 0.59) + (originalcolor.B * 0.11));

                    Color graycolor = Color.FromArgb(grayScale, grayScale, grayScale);
                    newBitmap.SetPixel(x, y, graycolor);
                }

            return newBitmap;
        }
        private void button1_Click(object sender, EventArgs e)
        {//借閱按鈕
            int bookId = Convert.ToInt32(label19.Text);//存放書的 ID
            books = BookDataHelp.Loadbooks();
            var book = books.FirstOrDefault(b => b.Id == bookId);

            if (!ValidateUserInput(out string userName, out string phone, out string email)) return;

            if (book != null && book.isBorrowed == false)
            {
                BookDataHelp.MarkBookAsBorrowed(books, bookId);//將借閱的書更新狀態
                label5.Text = "10 點";
                SendEmail(email, "借閱", userName, phone, book); //送email給使用者

                RecordItem record = new RecordItem
                {
                    bookId = bookId,
                    title = label17.Text,
                    status = "借閱中",
                    date = DateTime.Now.ToString("yyyy-MM-dd HH:mm"),
                    dueDate = DateTime.Now.AddDays(14).ToString("yyyy-MM-dd")
                };

                UserDataHelp.AddRecord(userName, phone, email, record, 10);//紀錄使用者借閱資訊

                MessageBox.Show("借閱成功！\n將會寄送一封Email給您");
                frontPage.Show();
                this.Hide();
                UpdateBookImages();
            }
            else
            {
                DialogResult result = MessageBox.Show(
                    "此書目前不可借閱，是否要預約？",
                    "無法借閱",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    // 使用者選擇「是」→ 預約流程
                    RecordItem record = new RecordItem
                    {
                        bookId = bookId,
                        title = label17.Text,
                        status = "預約中",
                        date = DateTime.Now.ToString("yyyy-MM-dd HH:mm"),
                        dueDate =null
                    };

                    UserDataHelp.AddRecord(userName, phone, email, record, 0); // 加入預約資訊（不加點數）
                    SendEmail(email, "預約", userName, phone, book); // 寄送預約通知Email

                    MessageBox.Show("已完成預約，系統將會通知您可借閱時機。", "預約成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    // 使用者選擇「否」→ 不做任何處理
                    MessageBox.Show("已取消操作。", "取消", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
        
        private void button4_Click(object sender, EventArgs e)
        {
            int bookId = Convert.ToInt32(label19.Text); //存放書的 ID
            books = BookDataHelp.Loadbooks();
            var book = books.FirstOrDefault(x => x.Id == bookId);

            if (!ValidateUserInput(out string userName, out string phone, out string email)) return;

            if (book.isBorrowed == false)
            {
                MessageBox.Show("此書目前可借閱，無須預約。");
                return;
            }

            if (book != null && book.isBorrowed == true)
            {
                SendEmail(email, "預約", userName, phone, book);

                RecordItem record = new RecordItem
                {
                    bookId = bookId,
                    title = label17.Text,
                    status = "預約中",
                    date = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                };
                UserDataHelp.AddRecord(userName, phone, email, record, 0);

                MessageBox.Show("預約成功！\n將會寄送一封Email給您");
                frontPage.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("書籍不存在！");
                return;
            }
        }

        private bool ValidateUserInput(out string userName, out string phone, out string email)
        {// 檢查是否有欄位未填寫之方法
            userName = textBox1.Text.Trim();
            phone = textBox2.Text.Trim();
            email = textBox3.Text.Trim();

            if (string.IsNullOrEmpty(userName) || string.IsNullOrEmpty(phone) || string.IsNullOrEmpty(email))
            {
                MessageBox.Show("請完整填寫姓名、電話和Email。", "輸入不完整", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!Regex.IsMatch(phone, @"^\d{10}$"))
            {
                MessageBox.Show("請輸入正確的10碼電話號碼。", "格式錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("請輸入正確的Email格式。", "格式錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }
        private void SendEmail(string email, string type, string name, string phone, Books book)//寄送email方法
        {
            try
            {
                MailMessage mail = new MailMessage();
                mail.From = new MailAddress("from@example.com");
                mail.To.Add(email);
                mail.Subject = "佐米租書及預約";
                mail.SubjectEncoding = Encoding.UTF8;
                mail.BodyEncoding = Encoding.UTF8;

                string commonInfo = $"以下是您於本系統{type}之相關資料：\n書名：{book.BookName}\n作者：{book.Author}\n出版年分：{book.Year}\n編號：{book.Id}" +
                    $"\n\n您填寫的基本資料如下：\n姓名：{name}\n電話：{phone}";

                string body;

                if (type == "借閱")
                {
                    body = "顧客您好，您已成功借閱書籍" + commonInfo +
                           $"\n\n請準時於兩週後歸還，謝謝您的使用！" +
                           $"\n\n到期日：{DateTime.Now.AddDays(14):yyyy-MM-dd}";
                }
                else if (type == "預約")
                {
                    body = "顧客您好，您已成功預約書籍" + commonInfo +
                           "\n\n系統將於書籍可借閱時通知您，請耐心等候。謝謝您的使用！";
                }
                else
                {
                    body = "顧客您好，這是系統通知信件。" + commonInfo;
                }

                mail.Body = body;

                using (SmtpClient smtp = new SmtpClient("sandbox.smtp.mailtrap.io", 2525))
                {
                    smtp.Credentials = new NetworkCredential("bff03953365917", "6a4e4061fbb7e4");
                    smtp.EnableSsl = true;
                    smtp.Send(mail);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{type}失敗，請填寫正確資料\n{ex.Message}");
            }
        }
        private void button2_Click(object sender, EventArgs e)//【我的借閱紀錄】按鈕
        {
            FormHistory formHistory = new FormHistory();
            formHistory.Show();
            this.Hide();
        }
    }
}
