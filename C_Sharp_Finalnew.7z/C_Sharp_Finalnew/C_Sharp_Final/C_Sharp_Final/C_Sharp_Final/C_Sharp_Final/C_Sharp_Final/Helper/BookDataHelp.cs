﻿using C_Sharp_Final.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using C_Sharp_Final.Helper;

namespace C_Sharp_Final.Helper
{
    public class BookDataHelp
    {
        private static string jsonPath = JsonPathHelper.GetBookPath();

        public static List<Books> Loadbooks()
        {
            if (!File.Exists(jsonPath))
                return new List<Books>();

            string json = File.ReadAllText(jsonPath);
            return JsonSerializer.Deserialize<List<Books>>(json);
        }

        public static void SaveBooks(List<Books> books)
        {
            string json = JsonSerializer.Serialize(books, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(jsonPath, json);
        }
        public static void MarkBookAsBorrowed(List<Books> books, int bookId)
        {
            var book = books.FirstOrDefault(x => x.Id == bookId);
            if (book != null && book.isBorrowed == false)
            {
                book.isBorrowed = true;
                SaveBooks(books);
            }
        }
    }
}
