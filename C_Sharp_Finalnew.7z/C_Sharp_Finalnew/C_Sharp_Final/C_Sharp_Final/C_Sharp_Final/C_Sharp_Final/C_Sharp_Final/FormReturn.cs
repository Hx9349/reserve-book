﻿using C_Sharp_Final.Helper;
using C_Sharp_Final.Models;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace C_Sharp_Final
{
    public partial class FormReturn : Form
    {
        private List<Books> books;
        private List<UserData> users;
        private FormScaler scaler;
        public FormReturn()
        {
            InitializeComponent();
            scaler = new FormScaler(this);
        }

        private void FormReturn_Load(object sender, EventArgs e)
        {
            books = BookDataHelp.Loadbooks();
            users = UserDataHelp.LoadUserData();
        }
        private void button1_Click(object sender, EventArgs e)
        {//【確認歸還】按鈕
            if (int.TryParse(txtBookId.Text, out int bookId))
            {
                var book = books.FirstOrDefault(c => c.Id == bookId);
                if (book != null && book.isBorrowed)
                {
                    // 找出借了這本書的使用者
                    var user = users.FirstOrDefault(u =>
                        u.records.Any(r => r.bookId == bookId && r.status == "借閱中"));

                    if (user != null)
                    {
                        // 更新書籍狀態
                        book.isBorrowed = false;
                        BookDataHelp.SaveBooks(books); // 儲存書籍變更

                        // 更新紀錄
                        var record = user.records.FirstOrDefault(r => r.bookId == bookId && r.status == "借閱中");
                        if (record != null)
                        {
                            record.status = "已歸還";
                            record.date = DateTime.Now.ToString("yyyy-MM-dd HH:mm");
                            record.dueDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm");
                        }

                        // 儲存使用者資料
                        UserDataHelp.SaveUserData(users);

                        MessageBox.Show("書籍歸還成功，紀錄已更新！");
                        FrontPage frontPage = new FrontPage();
                        frontPage.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("找不到借閱此書的使用者！");
                    }
                }
                else
                {
                    MessageBox.Show("此書尚未借出或不存在");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrontPage home = new FrontPage();
            home.Show();
            this.Hide();
        }

        private void txtBookId_KeyPress(object sender, KeyPressEventArgs e)
        {
            // 控制使用者不輸入無效書籍編號
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void Botton4_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtBookId.Text, out int bookId))
            {
                // 找書籍
                var book = books.FirstOrDefault(b => b.Id == bookId);

                if (book != null && book.isBorrowed)
                {
                    // 從所有使用者中找出有借這本書的人
                    var user = users.FirstOrDefault(u =>
                        u.records.Any(r => r.bookId == bookId && r.status == "借閱中"));

                    if (user != null)
                    {
                        // 顯示使用者資料
                        lblUserName.Text = user.name;
                        lblPhone.Text = user.phone;
                        lblEmail.Text = user.email;

                        // 顯示書籍資料
                        lblBN.Text = book.BookName;
                        lblBArt.Text = book.Author;
                        lblBY.Text = book.Year;
                    }
                    else
                    {
                        MessageBox.Show("找不到借閱此書的使用者");
                    }
                }
                else
                {
                    lblBN.Text = "無此書籍，或此書未借出";
                    lblBArt.Text = "";
                    lblBY.Text = "";
                }
            }
            else
            {
                MessageBox.Show("請輸入有效的書籍編號");
            }
        }

        private void txtBookId_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBookId.Text))
            {
                lblBN.Text = "";
                lblBArt.Text = "";
                lblBY.Text = "";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {//【借閱紀錄】按鈕
            FormHistory formHistory = new FormHistory();
            formHistory.Show();
            this.Hide();
        }

        private void txtBookId_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnconfrim.PerformClick();
                e.SuppressKeyPress = true;
            }
        }
    }
}
