﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_Final.Models
{
    public class ExchangeRecord
    {
        public string userEmail { get; set; }
        public string userName { get; set; }
        public string prize { get; set; }
        public string date { get; set; }
    }
}
