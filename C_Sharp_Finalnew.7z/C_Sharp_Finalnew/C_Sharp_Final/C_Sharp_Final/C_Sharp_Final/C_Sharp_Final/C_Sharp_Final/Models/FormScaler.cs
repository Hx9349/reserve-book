﻿using System;
using System.Drawing;
using System.Windows.Forms;

public class FormScaler
{
    private Form targetForm;
    private Size originalFormSize;
    private bool isFirstResize = true;

    public FormScaler(Form form)
    {
        targetForm = form;
        originalFormSize = form.Size;

        // 綁定 Resize 事件
        form.Resize += OnFormResize;
    }

    private void OnFormResize(object sender, EventArgs e)
    {
        if (isFirstResize)
        {
            isFirstResize = false;
            return;
        }

        float xRatio = (float)targetForm.Width / originalFormSize.Width;
        float yRatio = (float)targetForm.Height / originalFormSize.Height;

        float scaleRatio = Math.Min(xRatio, yRatio); // 等比例縮放
        targetForm.Scale(new SizeF(scaleRatio, scaleRatio));
    }
}