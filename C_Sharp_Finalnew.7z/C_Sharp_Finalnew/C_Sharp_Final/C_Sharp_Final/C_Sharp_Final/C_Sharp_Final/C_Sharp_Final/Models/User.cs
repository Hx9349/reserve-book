﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_Final.Models
{
    public class RecordItem
    {
        public int bookId { get; set; }
        public string title { get; set; }
        public string status { get; set; }  // "借閱中"or"預約中"
        public string date { get; set; }    // 例如 "2025-06-01 19:30"
        public string? dueDate { get; set; }   // ← 加入這個欄位，只有借書時會設定
    }

    public class UserData
    {
        public string email { get; set; }
        public string name { get; set; }
        public string phone { get; set; }
        public int points { get; set; }
        public List<RecordItem> records { get; set; } = new List<RecordItem>();
    }
}
