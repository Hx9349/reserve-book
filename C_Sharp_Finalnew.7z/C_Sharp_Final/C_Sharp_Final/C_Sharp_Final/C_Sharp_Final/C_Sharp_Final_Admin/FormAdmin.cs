using C_Sharp_Final.Models;
using Microsoft.VisualBasic.ApplicationServices;
using C_Sharp_Final.Helper;

namespace C_Sharp_Final_Admin
{
    public partial class FormAdmin : Form
    {
        private List<Books> books;
        private List<UserData> usersData;
        private List<ExchangeRecord> exchangeRecords;
        public FormAdmin()
        {
            InitializeComponent();
        }
        private void FormAdmin_Load_2(object sender, EventArgs e)
        {
            LoadAllData();
        }
        private void LoadAllData()
        {
            LoadBooks();
            LoadUsers();
            LoadExchangeRecords();
        }
        private void LoadBooks()
        {
            string path = JsonPathHelper.GetBookPath();

            if (File.Exists(path))
            {
                books = BookDataHelp.Loadbooks(); // �ۭq Helper ���J

                MessageBox.Show($"���J���y���ơG{books.Count}"); // �o�i�H���A�T�w��Ưu�����Q���J

                dgvBooks.Rows.Clear();
                dgvBooks.Columns.Clear();

                dgvBooks.Columns.Add("bookId", "���y ID");
                dgvBooks.Columns.Add("title", "�ѦW");
                dgvBooks.Columns.Add("author", "�@��");
                dgvBooks.Columns.Add("year", "�X���~");
                dgvBooks.Columns.Add("isAvailable", "�i�ɾ\");

                foreach (var book in books)
                {
                    dgvBooks.Rows.Add(book.Id, book.BookName, book.Author, book.Year, book.isBorrowed ? "�_" : "�O");
                }
            }
            else
            {
                MessageBox.Show("�䤣�� books.json �ɮסI");
            }
        }

        private void LoadUsers()
        {
            string path = JsonPathHelper.GetUserPath();
            if (File.Exists(path))
            {
                usersData = UserDataHelp.LoadUserData();

                dgvUsers.Columns.Clear();

                dgvUsers.Columns.Add("name", "�m�W");
                dgvUsers.Columns.Add("email", "Email");
                dgvUsers.Columns.Add("phone", "�q��");
                dgvUsers.Columns.Add("points", "�I��");

                foreach (var user in usersData)
                {
                    dgvUsers.Rows.Add(user.name, user.email, user.phone, user.points);
                }
            }
        }

        private void LoadExchangeRecords()
        {
            string path = JsonPathHelper.GetExchangePath();
            if (File.Exists(path))
            {
                exchangeRecords = ExchangeRecordHelp.LoadProintRecords();
                lstExchangeHistory.Items.Clear();
                foreach (var record in exchangeRecords)
                {
                    string item = $"{record.date} - {record.userName} ({record.userEmail}) �I���F {record.prize}";
                    lstExchangeHistory.Items.Add(item);
                }
            }
        }
        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            var result = MessageBox.Show("�T�{�R�����y�H", "�T�{", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result != DialogResult.Yes)
                return;

            int bookId;
            if (int.TryParse(txtBookId.Text, out bookId))
            {
                books = BookDataHelp.Loadbooks();
                var bookToRemove = books.FirstOrDefault(b => b.Id == bookId);
                if (bookToRemove != null)
                {
                    books.Remove(bookToRemove);
                    BookDataHelp.SaveBooks(books);
                    MessageBox.Show("�R�����\");
                    LoadBooks(); // ���s���J���
                }
                else
                {
                    MessageBox.Show("�䤣��Ӯ��y");
                }
            }
            else
            {
                MessageBox.Show("�п�J���Ī����y ID");
            }
        }
        private void dgvUsers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string selectedEmail = dgvUsers.Rows[e.RowIndex].Cells["email"].Value.ToString();

                var selectedUser = usersData.FirstOrDefault(u => u.email == selectedEmail);

                if (selectedUser != null && selectedUser.records != null)
                {
                    dgvUBStauts.Columns.Clear();
                    dgvUBStauts.Rows.Clear();

                    dgvUBStauts.Columns.Add("bookId", "���y ID");
                    dgvUBStauts.Columns.Add("title", "�ѦW");
                    dgvUBStauts.Columns.Add("status", "���A");
                    dgvUBStauts.Columns.Add("date", "���");

                    foreach (var record in selectedUser.records)
                    {
                        dgvUBStauts.Rows.Add(record.bookId, record.title, record.status, record.date);
                    }
                }
            }
        }
    }
}
