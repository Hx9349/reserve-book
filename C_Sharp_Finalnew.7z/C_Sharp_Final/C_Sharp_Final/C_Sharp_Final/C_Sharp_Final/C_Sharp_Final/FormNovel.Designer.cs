﻿namespace C_Sharp_Final
{
    partial class FormNovel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormNovel));
            comBclass = new ComboBox();
            panel1 = new Panel();
            lblNbID4 = new Label();
            label21 = new Label();
            lblNbID3 = new Label();
            label16 = new Label();
            lblNbID2 = new Label();
            label14 = new Label();
            lblNbID1 = new Label();
            label18 = new Label();
            richTextBox4 = new RichTextBox();
            richTextBox3 = new RichTextBox();
            richTextBox2 = new RichTextBox();
            richTextBox1 = new RichTextBox();
            lblNbAt2 = new Label();
            lblNbY2 = new Label();
            lblNbN2 = new Label();
            lblNbAt4 = new Label();
            lblNbY4 = new Label();
            lblNbN4 = new Label();
            lblNbAt3 = new Label();
            lblNbY3 = new Label();
            lblNbN3 = new Label();
            lblNbAt1 = new Label();
            lblNbY1 = new Label();
            lblNbN1 = new Label();
            btnNb1 = new Button();
            btnNb3 = new Button();
            btnNb4 = new Button();
            btnNb2 = new Button();
            label11 = new Label();
            label12 = new Label();
            label7 = new Label();
            label8 = new Label();
            label5 = new Label();
            label6 = new Label();
            label10 = new Label();
            label9 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            btnNbI2 = new Button();
            btnNbI4 = new Button();
            btnNbI3 = new Button();
            btnNbI1 = new Button();
            button2 = new Button();
            label17 = new Label();
            button1 = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // comBclass
            // 
            comBclass.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comBclass.FormattingEnabled = true;
            comBclass.Items.AddRange(new object[] { "漫畫", "小說" });
            comBclass.Location = new Point(85, 18);
            comBclass.Name = "comBclass";
            comBclass.Size = new Size(137, 28);
            comBclass.TabIndex = 5;
            comBclass.Text = "選擇書籍類別";
            comBclass.SelectedIndexChanged += comBclass_SelectedIndexChanged;
            // 
            // panel1
            // 
            panel1.AutoScroll = true;
            panel1.Controls.Add(lblNbID4);
            panel1.Controls.Add(label21);
            panel1.Controls.Add(lblNbID3);
            panel1.Controls.Add(label16);
            panel1.Controls.Add(lblNbID2);
            panel1.Controls.Add(label14);
            panel1.Controls.Add(lblNbID1);
            panel1.Controls.Add(label18);
            panel1.Controls.Add(richTextBox4);
            panel1.Controls.Add(richTextBox3);
            panel1.Controls.Add(richTextBox2);
            panel1.Controls.Add(richTextBox1);
            panel1.Controls.Add(lblNbAt2);
            panel1.Controls.Add(lblNbY2);
            panel1.Controls.Add(lblNbN2);
            panel1.Controls.Add(lblNbAt4);
            panel1.Controls.Add(lblNbY4);
            panel1.Controls.Add(lblNbN4);
            panel1.Controls.Add(lblNbAt3);
            panel1.Controls.Add(lblNbY3);
            panel1.Controls.Add(lblNbN3);
            panel1.Controls.Add(lblNbAt1);
            panel1.Controls.Add(lblNbY1);
            panel1.Controls.Add(lblNbN1);
            panel1.Controls.Add(btnNb1);
            panel1.Controls.Add(btnNb3);
            panel1.Controls.Add(btnNb4);
            panel1.Controls.Add(btnNb2);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(label12);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(btnNbI2);
            panel1.Controls.Add(btnNbI4);
            panel1.Controls.Add(btnNbI3);
            panel1.Controls.Add(btnNbI1);
            panel1.Location = new Point(12, 54);
            panel1.Name = "panel1";
            panel1.Size = new Size(1185, 653);
            panel1.TabIndex = 6;
            // 
            // lblNbID4
            // 
            lblNbID4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblNbID4.Location = new Point(961, 419);
            lblNbID4.Name = "lblNbID4";
            lblNbID4.Size = new Size(78, 20);
            lblNbID4.TabIndex = 125;
            lblNbID4.Text = "24";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label21.Location = new Point(909, 419);
            label21.Name = "label21";
            label21.Size = new Size(57, 20);
            label21.TabIndex = 124;
            label21.Text = "編號：";
            // 
            // lblNbID3
            // 
            lblNbID3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblNbID3.Location = new Point(359, 419);
            lblNbID3.Name = "lblNbID3";
            lblNbID3.Size = new Size(78, 20);
            lblNbID3.TabIndex = 123;
            lblNbID3.Text = "23";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label16.Location = new Point(307, 419);
            label16.Name = "label16";
            label16.Size = new Size(57, 20);
            label16.TabIndex = 122;
            label16.Text = "編號：";
            // 
            // lblNbID2
            // 
            lblNbID2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblNbID2.Location = new Point(940, 87);
            lblNbID2.Name = "lblNbID2";
            lblNbID2.Size = new Size(78, 20);
            lblNbID2.TabIndex = 121;
            lblNbID2.Text = "22";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label14.Location = new Point(893, 87);
            label14.Name = "label14";
            label14.Size = new Size(57, 20);
            label14.TabIndex = 120;
            label14.Text = "編號：";
            // 
            // lblNbID1
            // 
            lblNbID1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblNbID1.Location = new Point(359, 87);
            lblNbID1.Name = "lblNbID1";
            lblNbID1.Size = new Size(78, 20);
            lblNbID1.TabIndex = 119;
            lblNbID1.Text = "21";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label18.Location = new Point(307, 87);
            label18.Name = "label18";
            label18.Size = new Size(57, 20);
            label18.TabIndex = 118;
            label18.Text = "編號：";
            // 
            // richTextBox4
            // 
            richTextBox4.BackColor = SystemColors.Control;
            richTextBox4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            richTextBox4.Location = new Point(616, 469);
            richTextBox4.Name = "richTextBox4";
            richTextBox4.Size = new Size(423, 195);
            richTextBox4.TabIndex = 117;
            richTextBox4.Text = resources.GetString("richTextBox4.Text");
            // 
            // richTextBox3
            // 
            richTextBox3.BackColor = SystemColors.Control;
            richTextBox3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            richTextBox3.Location = new Point(28, 469);
            richTextBox3.Name = "richTextBox3";
            richTextBox3.Size = new Size(425, 195);
            richTextBox3.TabIndex = 116;
            richTextBox3.Text = resources.GetString("richTextBox3.Text");
            // 
            // richTextBox2
            // 
            richTextBox2.BackColor = SystemColors.Control;
            richTextBox2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            richTextBox2.Location = new Point(28, 132);
            richTextBox2.Name = "richTextBox2";
            richTextBox2.Size = new Size(425, 195);
            richTextBox2.TabIndex = 115;
            richTextBox2.Text = resources.GetString("richTextBox2.Text");
            // 
            // richTextBox1
            // 
            richTextBox1.BackColor = SystemColors.Control;
            richTextBox1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            richTextBox1.Location = new Point(616, 132);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(423, 195);
            richTextBox1.TabIndex = 114;
            richTextBox1.Text = resources.GetString("richTextBox1.Text");
            // 
            // lblNbAt2
            // 
            lblNbAt2.AutoSize = true;
            lblNbAt2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblNbAt2.Location = new Point(765, 58);
            lblNbAt2.Name = "lblNbAt2";
            lblNbAt2.Size = new Size(73, 20);
            lblNbAt2.TabIndex = 109;
            lblNbAt2.Text = "七月隆文";
            // 
            // lblNbY2
            // 
            lblNbY2.AutoSize = true;
            lblNbY2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblNbY2.Location = new Point(792, 87);
            lblNbY2.Name = "lblNbY2";
            lblNbY2.Size = new Size(95, 20);
            lblNbY2.TabIndex = 108;
            lblNbY2.Text = "2023/04/01";
            // 
            // lblNbN2
            // 
            lblNbN2.AutoSize = true;
            lblNbN2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblNbN2.Location = new Point(765, 32);
            lblNbN2.Name = "lblNbN2";
            lblNbN2.Size = new Size(201, 20);
            lblNbN2.TabIndex = 107;
            lblNbN2.Text = "明天，我要和昨天的妳約會";
            // 
            // lblNbAt4
            // 
            lblNbAt4.AutoSize = true;
            lblNbAt4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblNbAt4.Location = new Point(765, 390);
            lblNbAt4.Name = "lblNbAt4";
            lblNbAt4.Size = new Size(57, 20);
            lblNbAt4.TabIndex = 106;
            lblNbAt4.Text = "萬特特";
            // 
            // lblNbY4
            // 
            lblNbY4.AutoSize = true;
            lblNbY4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblNbY4.Location = new Point(792, 419);
            lblNbY4.Name = "lblNbY4";
            lblNbY4.Size = new Size(95, 20);
            lblNbY4.TabIndex = 105;
            lblNbY4.Text = "2020/01/08";
            // 
            // lblNbN4
            // 
            lblNbN4.AutoSize = true;
            lblNbN4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblNbN4.Location = new Point(765, 364);
            lblNbN4.Name = "lblNbN4";
            lblNbN4.Size = new Size(201, 20);
            lblNbN4.TabIndex = 104;
            lblNbN4.Text = "這世界很煩，但你要很可愛";
            // 
            // lblNbAt3
            // 
            lblNbAt3.AutoSize = true;
            lblNbAt3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblNbAt3.Location = new Point(177, 390);
            lblNbAt3.Name = "lblNbAt3";
            lblNbAt3.Size = new Size(93, 20);
            lblNbAt3.TabIndex = 103;
            lblNbAt3.Text = "泰絲‧格里森";
            // 
            // lblNbY3
            // 
            lblNbY3.AutoSize = true;
            lblNbY3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblNbY3.Location = new Point(203, 419);
            lblNbY3.Name = "lblNbY3";
            lblNbY3.Size = new Size(95, 20);
            lblNbY3.TabIndex = 102;
            lblNbY3.Text = "2017/08/31";
            // 
            // lblNbN3
            // 
            lblNbN3.AutoSize = true;
            lblNbN3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblNbN3.Location = new Point(177, 364);
            lblNbN3.Name = "lblNbN3";
            lblNbN3.Size = new Size(173, 20);
            lblNbN3.TabIndex = 101;
            lblNbN3.Text = "外科醫生 The Surgeon";
            // 
            // lblNbAt1
            // 
            lblNbAt1.AutoSize = true;
            lblNbAt1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblNbAt1.Location = new Point(177, 58);
            lblNbAt1.Name = "lblNbAt1";
            lblNbAt1.Size = new Size(41, 20);
            lblNbAt1.TabIndex = 100;
            lblNbAt1.Text = "顧漫";
            // 
            // lblNbY1
            // 
            lblNbY1.AutoSize = true;
            lblNbY1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblNbY1.Location = new Point(203, 87);
            lblNbY1.Name = "lblNbY1";
            lblNbY1.Size = new Size(95, 20);
            lblNbY1.TabIndex = 99;
            lblNbY1.Text = "2022/07/01";
            // 
            // lblNbN1
            // 
            lblNbN1.AutoSize = true;
            lblNbN1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblNbN1.Location = new Point(177, 32);
            lblNbN1.Name = "lblNbN1";
            lblNbN1.Size = new Size(121, 20);
            lblNbN1.TabIndex = 98;
            lblNbN1.Text = "微微一笑很傾城";
            // 
            // btnNb1
            // 
            btnNb1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnNb1.Location = new Point(468, 294);
            btnNb1.Name = "btnNb1";
            btnNb1.Size = new Size(99, 33);
            btnNb1.TabIndex = 97;
            btnNb1.Text = "借閱/ 預約";
            btnNb1.UseVisualStyleBackColor = true;
            // 
            // btnNb3
            // 
            btnNb3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnNb3.Location = new Point(468, 622);
            btnNb3.Name = "btnNb3";
            btnNb3.Size = new Size(99, 33);
            btnNb3.TabIndex = 96;
            btnNb3.Text = "借閱/ 預約";
            btnNb3.UseVisualStyleBackColor = true;
            // 
            // btnNb4
            // 
            btnNb4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnNb4.Location = new Point(1050, 622);
            btnNb4.Name = "btnNb4";
            btnNb4.Size = new Size(99, 33);
            btnNb4.TabIndex = 95;
            btnNb4.Text = "借閱/ 預約";
            btnNb4.UseVisualStyleBackColor = true;
            // 
            // btnNb2
            // 
            btnNb2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnNb2.Location = new Point(1050, 294);
            btnNb2.Name = "btnNb2";
            btnNb2.Size = new Size(99, 33);
            btnNb2.TabIndex = 94;
            btnNb2.Text = "借閱/ 預約";
            btnNb2.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label11.Location = new Point(709, 87);
            label11.Name = "label11";
            label11.Size = new Size(89, 20);
            label11.TabIndex = 89;
            label11.Text = "出版年分：";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label12.Location = new Point(709, 58);
            label12.Name = "label12";
            label12.Size = new Size(57, 20);
            label12.TabIndex = 88;
            label12.Text = "作者：";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label7.Location = new Point(121, 419);
            label7.Name = "label7";
            label7.Size = new Size(89, 20);
            label7.TabIndex = 87;
            label7.Text = "出版年分：";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label8.Location = new Point(121, 390);
            label8.Name = "label8";
            label8.Size = new Size(57, 20);
            label8.TabIndex = 86;
            label8.Text = "作者：";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label5.Location = new Point(709, 419);
            label5.Name = "label5";
            label5.Size = new Size(89, 20);
            label5.TabIndex = 85;
            label5.Text = "出版年分：";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label6.Location = new Point(709, 390);
            label6.Name = "label6";
            label6.Size = new Size(57, 20);
            label6.TabIndex = 84;
            label6.Text = "作者：";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label10.Location = new Point(121, 87);
            label10.Name = "label10";
            label10.Size = new Size(89, 20);
            label10.TabIndex = 83;
            label10.Text = "出版年分：";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label9.Location = new Point(121, 58);
            label9.Name = "label9";
            label9.Size = new Size(57, 20);
            label9.TabIndex = 82;
            label9.Text = "作者：";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label4.Location = new Point(709, 364);
            label4.Name = "label4";
            label4.Size = new Size(57, 20);
            label4.TabIndex = 81;
            label4.Text = "書名：";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label3.Location = new Point(121, 364);
            label3.Name = "label3";
            label3.Size = new Size(57, 20);
            label3.TabIndex = 80;
            label3.Text = "書名：";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label2.Location = new Point(709, 32);
            label2.Name = "label2";
            label2.Size = new Size(57, 20);
            label2.TabIndex = 79;
            label2.Text = "書名：";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label1.Location = new Point(121, 32);
            label1.Name = "label1";
            label1.Size = new Size(57, 20);
            label1.TabIndex = 78;
            label1.Text = "書名：";
            // 
            // btnNbI2
            // 
            btnNbI2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnNbI2.Location = new Point(616, 18);
            btnNbI2.Name = "btnNbI2";
            btnNbI2.Size = new Size(87, 100);
            btnNbI2.TabIndex = 77;
            btnNbI2.Text = "b2(書封照片)";
            btnNbI2.UseVisualStyleBackColor = true;
            // 
            // btnNbI4
            // 
            btnNbI4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnNbI4.Location = new Point(616, 350);
            btnNbI4.Name = "btnNbI4";
            btnNbI4.Size = new Size(87, 100);
            btnNbI4.TabIndex = 76;
            btnNbI4.Text = "b4(書封照片)";
            btnNbI4.UseVisualStyleBackColor = true;
            // 
            // btnNbI3
            // 
            btnNbI3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnNbI3.Location = new Point(28, 350);
            btnNbI3.Name = "btnNbI3";
            btnNbI3.Size = new Size(87, 100);
            btnNbI3.TabIndex = 75;
            btnNbI3.Text = "b3(書封照片)";
            btnNbI3.UseVisualStyleBackColor = true;
            // 
            // btnNbI1
            // 
            btnNbI1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnNbI1.Location = new Point(28, 18);
            btnNbI1.Name = "btnNbI1";
            btnNbI1.Size = new Size(87, 100);
            btnNbI1.TabIndex = 74;
            btnNbI1.Text = "b1(書封照片)";
            btnNbI1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(980, 9);
            button2.Name = "button2";
            button2.Size = new Size(123, 36);
            button2.TabIndex = 69;
            button2.Text = "我的借閱紀錄";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 178);
            label17.Location = new Point(31, 18);
            label17.Name = "label17";
            label17.Size = new Size(48, 22);
            label17.TabIndex = 7;
            label17.Text = "小說";
            // 
            // button1
            // 
            button1.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(905, 9);
            button1.Name = "button1";
            button1.Size = new Size(69, 36);
            button1.TabIndex = 70;
            button1.Text = "首頁";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // FormNovel
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1202, 719);
            Controls.Add(button1);
            Controls.Add(button2);
            Controls.Add(label17);
            Controls.Add(panel1);
            Controls.Add(comBclass);
            Name = "FormNovel";
            Text = "Form3";
            Load += FormNovel_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comBclass;
        private Panel panel1;
        private Label lblNbAt2;
        private Label lblNbY2;
        private Label lblNbN2;
        private Label lblNbAt4;
        private Label lblNbY4;
        private Label lblNbN4;
        private Label lblNbAt3;
        private Label lblNbY3;
        private Label lblNbN3;
        private Label lblNbAt1;
        private Label lblNbY1;
        private Label lblNbN1;
        private Button btnNb1;
        private Button btnNb3;
        private Button btnNb4;
        private Button btnNb2;
        private Label label11;
        private Label label12;
        private Label label7;
        private Label label8;
        private Label label5;
        private Label label6;
        private Label label10;
        private Label label9;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        public Button btnNbI2;
        public Button btnNbI4;
        public Button btnNbI3;
        public Button btnNbI1;
        private Label label17;
        private RichTextBox richTextBox1;
        private RichTextBox richTextBox3;
        private RichTextBox richTextBox2;
        private RichTextBox richTextBox4;
        private Label lblNbID4;
        private Label label21;
        private Label lblNbID3;
        private Label label16;
        private Label lblNbID2;
        private Label label14;
        private Label lblNbID1;
        private Label label18;
        private Button button2;
        private Button button1;
    }
}