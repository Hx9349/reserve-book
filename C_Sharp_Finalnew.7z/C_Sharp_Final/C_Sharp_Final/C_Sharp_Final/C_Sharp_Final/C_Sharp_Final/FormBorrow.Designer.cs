﻿namespace C_Sharp_Final
{
    partial class FormBorrow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label10 = new Label();
            label11 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label4 = new Label();
            btnCancel = new Button();
            btnBorrow = new Button();
            textBox3 = new TextBox();
            label3 = new Label();
            textBox2 = new TextBox();
            label2 = new Label();
            textBox1 = new TextBox();
            label1 = new Label();
            label5 = new Label();
            label17 = new Label();
            button2 = new Button();
            saveFileDialog1 = new SaveFileDialog();
            btnReserve = new Button();
            label19 = new Label();
            label18 = new Label();
            SuspendLayout();
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label14.Location = new Point(35, 183);
            label14.Name = "label14";
            label14.Size = new Size(169, 20);
            label14.TabIndex = 62;
            label14.Text = "請填寫您的基本資料：";
            // 
            // label13
            // 
            label13.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label13.Location = new Point(116, 104);
            label13.Name = "label13";
            label13.Size = new Size(206, 20);
            label13.TabIndex = 61;
            // 
            // label12
            // 
            label12.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label12.Location = new Point(87, 73);
            label12.Name = "label12";
            label12.Size = new Size(229, 20);
            label12.TabIndex = 60;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label10.Location = new Point(35, 104);
            label10.Name = "label10";
            label10.Size = new Size(89, 20);
            label10.TabIndex = 59;
            label10.Text = "出版年分：";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label11.Location = new Point(35, 73);
            label11.Name = "label11";
            label11.Size = new Size(57, 20);
            label11.TabIndex = 58;
            label11.Text = "作者：";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label9.Location = new Point(157, 41);
            label9.Name = "label9";
            label9.Size = new Size(0, 20);
            label9.TabIndex = 57;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label8.Location = new Point(35, 41);
            label8.Name = "label8";
            label8.Size = new Size(121, 20);
            label8.TabIndex = 56;
            label8.Text = "你借閱的書名：";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label7.Location = new Point(35, 510);
            label7.Name = "label7";
            label7.Size = new Size(247, 20);
            label7.TabIndex = 55;
            label7.Text = "【借閱/預約 1本書可獲得 10 點】";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label6.Location = new Point(35, 551);
            label6.Name = "label6";
            label6.Size = new Size(216, 20);
            label6.TabIndex = 54;
            label6.Text = "【獲得150點 即可兌換禮卷】";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label4.Location = new Point(38, 464);
            label4.Name = "label4";
            label4.Size = new Size(109, 20);
            label4.TabIndex = 52;
            label4.Text = " 可獲得點數：";
            // 
            // btnCancel
            // 
            btnCancel.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnCancel.Location = new Point(136, 392);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(89, 36);
            btnCancel.TabIndex = 51;
            btnCancel.Text = "取消借閱";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += button3_Click;
            // 
            // btnBorrow
            // 
            btnBorrow.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnBorrow.Location = new Point(231, 392);
            btnBorrow.Name = "btnBorrow";
            btnBorrow.Size = new Size(89, 36);
            btnBorrow.TabIndex = 49;
            btnBorrow.Text = "確認借閱";
            btnBorrow.UseVisualStyleBackColor = true;
            btnBorrow.Click += button1_Click;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            textBox3.Location = new Point(103, 331);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(212, 28);
            textBox3.TabIndex = 48;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label3.Location = new Point(35, 331);
            label3.Name = "label3";
            label3.Size = new Size(66, 20);
            label3.TabIndex = 47;
            label3.Text = "Email：";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            textBox2.Location = new Point(103, 276);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(160, 28);
            textBox2.TabIndex = 46;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label2.Location = new Point(35, 276);
            label2.Name = "label2";
            label2.Size = new Size(57, 20);
            label2.TabIndex = 45;
            label2.Text = "電話：";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            textBox1.Location = new Point(103, 219);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(133, 28);
            textBox1.TabIndex = 44;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label1.Location = new Point(35, 219);
            label1.Name = "label1";
            label1.Size = new Size(57, 20);
            label1.TabIndex = 43;
            label1.Text = "姓名：";
            // 
            // label5
            // 
            label5.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label5.Location = new Point(140, 464);
            label5.Name = "label5";
            label5.Size = new Size(176, 20);
            label5.TabIndex = 53;
            // 
            // label17
            // 
            label17.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label17.Location = new Point(148, 42);
            label17.Name = "label17";
            label17.Size = new Size(229, 20);
            label17.TabIndex = 67;
            // 
            // button2
            // 
            button2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            button2.Location = new Point(348, 542);
            button2.Name = "button2";
            button2.Size = new Size(114, 36);
            button2.TabIndex = 68;
            button2.Text = "我的借閱紀錄";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // btnReserve
            // 
            btnReserve.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnReserve.Location = new Point(362, 392);
            btnReserve.Name = "btnReserve";
            btnReserve.Size = new Size(89, 36);
            btnReserve.TabIndex = 69;
            btnReserve.Text = "我要預約";
            btnReserve.UseVisualStyleBackColor = true;
            btnReserve.Click += button4_Click;
            // 
            // label19
            // 
            label19.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label19.Location = new Point(87, 142);
            label19.Name = "label19";
            label19.Size = new Size(78, 20);
            label19.TabIndex = 121;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label18.Location = new Point(35, 142);
            label18.Name = "label18";
            label18.Size = new Size(57, 20);
            label18.TabIndex = 120;
            label18.Text = "編號：";
            // 
            // FormBorrow
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(535, 641);
            Controls.Add(label19);
            Controls.Add(label18);
            Controls.Add(btnReserve);
            Controls.Add(button2);
            Controls.Add(label17);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(btnCancel);
            Controls.Add(btnBorrow);
            Controls.Add(textBox3);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Name = "FormBorrow";
            Text = "Form4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label10;
        private Label label11;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label4;
        private Button btnCancel;
        private Button btnBorrow;
        private TextBox textBox3;
        private Label label3;
        private TextBox textBox2;
        private Label label2;
        private TextBox textBox1;
        private Label label1;
        private Label label5;
        private Label label17;
        private Button button2;
        private SaveFileDialog saveFileDialog1;
        private Button btnReserve;
        private Label label19;
        private Label label18;
    }
}