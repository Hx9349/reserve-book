﻿using C_Sharp_Final.Helper;
using C_Sharp_Final.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_Sharp_Final
{
    public partial class FormHistory : Form
    {
        private List<UserData> users;
        private UserData user;
        private List<ExchangeRecord> exchangeRecords;
        public FormHistory()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string inputEmail = txtEmail1.Text.Trim();
            users = UserDataHelp.LoadUserData();
            user = users.FirstOrDefault(u => u.email == inputEmail);

            if (user == null)
            {
                MessageBox.Show("查無此用戶！");
                return;
            }

            label17.Text = user.name;
            label6.Text = user.phone;

            // 只建立欄位一次
            if (dataGridViewRecords.Columns.Count == 0)
            {
                dataGridViewRecords.Columns.Add("bookId", "書籍 ID");
                dataGridViewRecords.Columns.Add("title", "書名");
                dataGridViewRecords.Columns.Add("status", "狀態");
                dataGridViewRecords.Columns.Add("date", "日期");
            }

            // 清除舊資料
            dataGridViewRecords.Rows.Clear();

            // 加入每筆紀錄
            foreach (var record in user.records)
            {
                dataGridViewRecords.Rows.Add(record.bookId, record.title, record.status, record.date);
            }


            label7.Text = inputEmail;
            label15.Text = user.points.ToString() + " 點";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (user == null)
            {
                MessageBox.Show("請先查詢使用者！");
                return;
            }

            int points = user.points;
            if (points < 150)
            {
                MessageBox.Show("點數不足，無法兌換！");
                return;
            }

            if (comboBoxPrize.SelectedItem == null)
            {
                MessageBox.Show("請選擇一個兌換項目！");
                return;
            }
            string prize = comboBoxPrize.SelectedItem.ToString();

            user.points -= 150;
            var prointRecord = new ExchangeRecord
            {
                userEmail = user.email,
                userName = user.name,
                prize = prize,
                date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };
            ExchangeRecordHelp.AddProintRecord(prointRecord);
            UserDataHelp.SaveUserData(users); // 儲存使用者點數更新

            label15.Text = user.points + " 點";

            exchangeRecords = ExchangeRecordHelp.LoadProintRecords();
            // 清空顯示區
            lstExchangeRecord.Items.Clear();
            // 只顯示該使用者的兌換紀錄
            foreach (var record in exchangeRecords.Where(r => r.userEmail == user.email))
            {
                string display = $"兌換項目: {record.prize}, 日期: {record.date}";
                lstExchangeRecord.Items.Add(display);
            }

            MessageBox.Show($"您已成功兌換 {prize} 50元！");
        }

        private void txtEmail1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearch.PerformClick();
                e.SuppressKeyPress = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrontPage frontPage = new FrontPage();
            frontPage.Show();
            this.Hide();
        }
    }
}
