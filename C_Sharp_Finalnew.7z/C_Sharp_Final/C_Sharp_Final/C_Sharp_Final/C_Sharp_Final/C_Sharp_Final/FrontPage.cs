namespace C_Sharp_Final
{
    public partial class FrontPage : Form
    {
        public FrontPage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormComic mbpage = new FormComic();
            mbpage.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormNovel nbpage = new FormNovel();
            nbpage.Show();
            this.Hide();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            FormReturn formReturn = new FormReturn();
            formReturn.Show();
            this.Hide();
        }
    }
}
