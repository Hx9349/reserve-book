﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;
using C_Sharp_Final.Models;
using C_Sharp_Final.Helper;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace C_Sharp_Final
{
    public partial class FormBorrow : Form
    {
        private List<Books> books;
        FrontPage frontPage = new FrontPage();
        public FormBorrow()
        {
            InitializeComponent();
        }
        public void SetMbLblText(string Mname, string Mauthor, string Myear, int MBookId)
        {
            label17.Text = Mname;
            label12.Text = Mauthor;
            label13.Text = Myear;
            label19.Text = MBookId.ToString();
        }

        public void SetNbLblText(string Nname, string Nauthor, string Nyear, int NBookId)
        {
            label17.Text = Nname;
            label12.Text = Nauthor;
            label13.Text = Nyear;
            label19.Text = NBookId.ToString();
        }
        private void button3_Click(object sender, EventArgs e) //取消借閱按鈕
        {
            FormComic form2 = new FormComic();
            form2.Show();
            this.Close();
        }
        private void UpdateBookButtonImages()
        {
            books = BookDataHelp.Loadbooks();

            var bookButtonMap = new Dictionary<int, Button>
            {//照片配置
                { 11, new FormComic().btnMbI1 },
                { 12, new FormComic().btnMbI2 },
                { 13, new FormComic().btnMbI3 },
                { 14, new FormComic().btnMbI4 },
                { 21, new FormNovel().btnNbI1 },
                { 22, new FormNovel().btnNbI2 },
                { 23, new FormNovel().btnNbI3 },
                { 24, new FormNovel().btnNbI4 },
            };

            foreach (var book in books)
            {
                if (bookButtonMap.TryGetValue(book.Id, out Button btn))
                {
                    string imagePath = Path.Combine(Application.StartupPath, book.Image);

                    if (File.Exists(imagePath))
                    {
                        Image img = Image.FromFile(imagePath);
                        btn.Image = book.isBorrowed ? BookImageCray((Bitmap)img) : img;//將借走書的照片變成灰色
                        btn.ImageAlign = ContentAlignment.MiddleCenter;
                        btn.Text = "";
                        btn.FlatStyle = FlatStyle.Flat;
                    }
                }
            }
        }
        public static Bitmap BookImageCray(Bitmap original)
        {//將照片變灰色
            Bitmap newBitmap = new Bitmap(original.Width, original.Height);

            for (int y = 0; y < original.Height; y++)
                for (int x = 0; x < original.Width; x++)
                {
                    Color originalcolor = original.GetPixel(x, y);

                    int grayScale = (int)((originalcolor.R * 0.3) + (originalcolor.G * 0.59) + (originalcolor.B * 0.11));

                    Color graycolor = Color.FromArgb(grayScale, grayScale, grayScale);
                    newBitmap.SetPixel(x, y, graycolor);
                }

            return newBitmap;
        }
        private void button1_Click(object sender, EventArgs e)
        {//借閱按鈕
            string userName = textBox1.Text.Trim();//使用者資料輸入 TextBox
            string phone = textBox2.Text.Trim();
            string email = textBox3.Text.Trim();
            int bookId = Convert.ToInt32(label19.Text);//存放書的 ID
            books = BookDataHelp.Loadbooks();

            var book = books.FirstOrDefault(b => b.Id == bookId);
            if (book != null && book.isBorrowed == false)
            {
                BookDataHelp.MarkBookAsBorrowed(books, bookId);//將借閱的書更新狀態
                label5.Text = "10 點";
                SendEmail(email, "借閱", userName, phone, book); //送email給使用者

                RecordItem record = new RecordItem
                {
                    bookId = bookId,
                    title = label17.Text,
                    status = "借閱中",
                    date = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
                };
                UserDataHelp.AddRecord(userName, phone, email, record, 10);//紀錄使用者借閱資訊

                MessageBox.Show("借閱成功！\n將會寄送一封Email給您");
                frontPage.Show();
                this.Hide();
                UpdateBookButtonImages();
            }
            else
            {
                MessageBox.Show("此書目前不可借閱，須預約。");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string userName = textBox1.Text.Trim();//使用者資料輸入 TextBox
            string phone = textBox2.Text.Trim();
            string email = textBox3.Text.Trim();
            int bookId = Convert.ToInt32(label19.Text); //存放書的 ID

            var books = BookDataHelp.Loadbooks();
            var book = books.FirstOrDefault(x => x.Id == bookId);

            if (book == null)
            {
                MessageBox.Show("書籍不存在！");
                return;
            }

            if (book.isBorrowed == false)
            {
                MessageBox.Show("此書目前可借閱，無須預約。");
                return;
            }
            label5.Text = "預約同借閱可累計 10 點";
            SendEmail(email, "預約", userName, phone, book);

            RecordItem record = new RecordItem
            {
                bookId = bookId,
                title = label17.Text,
                status = "預約中",
                date = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
            };
            UserDataHelp.AddRecord(userName, phone, email, record, 10);

            MessageBox.Show("預約成功！\n將會寄送一封Email給您");
            frontPage.Show();
            this.Hide();
        }
        private void SendEmail(string email, string type, string name, string phone, Books book)//寄送email方法
        {
            try
            {
                MailMessage mail = new MailMessage();
                mail.From = new MailAddress("from@example.com");
                mail.To.Add(email);
                mail.Subject = "佐米租書及預約";
                mail.SubjectEncoding = Encoding.UTF8;
                mail.BodyEncoding = Encoding.UTF8;

                string body = $"顧客您好，您已成功{type}書籍\n\n以下是您於本系統{type}之相關資料：\n書名：{book.BookName}\n作者：{book.Author}\n出版年分：{book.Year}\n編號：{book.Id}" +
                    $"\n\n您填寫的基本資料如下：\n姓名：{name}\n電話：{phone}\n\n請準時歸還或等待通知，謝謝您的使用！";


                mail.Body = body;

                using (SmtpClient smtp = new SmtpClient("sandbox.smtp.mailtrap.io", 2525))
                {
                    smtp.Credentials = new NetworkCredential("bff03953365917", "6a4e4061fbb7e4");
                    smtp.EnableSsl = true;
                    smtp.Send(mail);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{type}失敗，請填寫正確資料\n{ex.Message}");
            }
        }
        private void button2_Click(object sender, EventArgs e)//【我的借閱紀錄】按鈕
        {
            FormHistory formHistory = new FormHistory();
            formHistory.Show();
            this.Hide();
        }
    }
}
