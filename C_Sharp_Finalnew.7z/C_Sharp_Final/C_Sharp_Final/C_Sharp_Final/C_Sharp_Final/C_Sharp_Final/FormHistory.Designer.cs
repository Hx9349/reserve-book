﻿namespace C_Sharp_Final
{
    partial class FormHistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            dataGridViewRecords = new DataGridView();
            btnSearch = new Button();
            label6 = new Label();
            label17 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtEmail1 = new TextBox();
            label4 = new Label();
            label3 = new Label();
            tabPage2 = new TabPage();
            comboBoxPrize = new ComboBox();
            label8 = new Label();
            lstExchangeRecord = new ListBox();
            label7 = new Label();
            label5 = new Label();
            button4 = new Button();
            label15 = new Label();
            label16 = new Label();
            button1 = new Button();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewRecords).BeginInit();
            tabPage2.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Font = new Font("Microsoft JhengHei UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            tabControl1.Location = new Point(2, 3);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(725, 592);
            tabControl1.TabIndex = 71;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(button1);
            tabPage1.Controls.Add(dataGridViewRecords);
            tabPage1.Controls.Add(btnSearch);
            tabPage1.Controls.Add(label6);
            tabPage1.Controls.Add(label17);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(txtEmail1);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(label3);
            tabPage1.Font = new Font("Arial Narrow", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tabPage1.Location = new Point(4, 28);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(717, 560);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "借閱紀錄";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridViewRecords
            // 
            dataGridViewRecords.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewRecords.BackgroundColor = SystemColors.Control;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridViewRecords.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewRecords.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Arial Narrow", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataGridViewRecords.DefaultCellStyle = dataGridViewCellStyle2;
            dataGridViewRecords.Location = new Point(64, 236);
            dataGridViewRecords.Name = "dataGridViewRecords";
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("Arial Narrow", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dataGridViewRecords.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dataGridViewRecords.RowHeadersWidth = 60;
            dataGridViewRecords.Size = new Size(536, 265);
            dataGridViewRecords.TabIndex = 100;
            // 
            // btnSearch
            // 
            btnSearch.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnSearch.Location = new Point(418, 44);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(70, 36);
            btnSearch.TabIndex = 86;
            btnSearch.Text = "查詢";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += button2_Click;
            // 
            // label6
            // 
            label6.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label6.Location = new Point(127, 126);
            label6.Name = "label6";
            label6.Size = new Size(145, 20);
            label6.TabIndex = 85;
            // 
            // label17
            // 
            label17.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label17.Location = new Point(127, 93);
            label17.Name = "label17";
            label17.Size = new Size(145, 20);
            label17.TabIndex = 84;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label2.Location = new Point(64, 126);
            label2.Name = "label2";
            label2.Size = new Size(57, 20);
            label2.TabIndex = 83;
            label2.Text = "電話：";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label1.Location = new Point(64, 93);
            label1.Name = "label1";
            label1.Size = new Size(57, 20);
            label1.TabIndex = 82;
            label1.Text = "姓名：";
            // 
            // txtEmail1
            // 
            txtEmail1.Font = new Font("微軟正黑體", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtEmail1.Location = new Point(125, 49);
            txtEmail1.Name = "txtEmail1";
            txtEmail1.Size = new Size(275, 27);
            txtEmail1.TabIndex = 81;
            txtEmail1.KeyDown += txtEmail1_KeyDown;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label4.Location = new Point(64, 213);
            label4.Name = "label4";
            label4.Size = new Size(89, 20);
            label4.TabIndex = 80;
            label4.Text = "借閱紀錄：";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label3.Location = new Point(64, 52);
            label3.Name = "label3";
            label3.Size = new Size(66, 20);
            label3.TabIndex = 79;
            label3.Text = "Email：";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(comboBoxPrize);
            tabPage2.Controls.Add(label8);
            tabPage2.Controls.Add(lstExchangeRecord);
            tabPage2.Controls.Add(label7);
            tabPage2.Controls.Add(label5);
            tabPage2.Controls.Add(button4);
            tabPage2.Controls.Add(label15);
            tabPage2.Controls.Add(label16);
            tabPage2.Font = new Font("Arial Narrow", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tabPage2.Location = new Point(4, 28);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(717, 560);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "點數紀錄";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // comboBoxPrize
            // 
            comboBoxPrize.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBoxPrize.FormattingEnabled = true;
            comboBoxPrize.Items.AddRange(new object[] { "Seven禮券 50元", "全聯禮券 50元", "家樂福禮券 50元", "圖書禮券 50元" });
            comboBoxPrize.Location = new Point(64, 156);
            comboBoxPrize.Name = "comboBoxPrize";
            comboBoxPrize.Size = new Size(184, 28);
            comboBoxPrize.TabIndex = 84;
            comboBoxPrize.Text = "選擇想兌換的禮卷";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label8.Location = new Point(64, 266);
            label8.Name = "label8";
            label8.Size = new Size(89, 20);
            label8.TabIndex = 83;
            label8.Text = "兌換記錄：";
            // 
            // lstExchangeRecord
            // 
            lstExchangeRecord.FormattingEnabled = true;
            lstExchangeRecord.ItemHeight = 20;
            lstExchangeRecord.Location = new Point(64, 289);
            lstExchangeRecord.Name = "lstExchangeRecord";
            lstExchangeRecord.Size = new Size(565, 204);
            lstExchangeRecord.TabIndex = 82;
            // 
            // label7
            // 
            label7.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label7.Location = new Point(125, 52);
            label7.Name = "label7";
            label7.Size = new Size(230, 25);
            label7.TabIndex = 81;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label5.Location = new Point(64, 52);
            label5.Name = "label5";
            label5.Size = new Size(66, 20);
            label5.TabIndex = 80;
            label5.Text = "Email：";
            // 
            // button4
            // 
            button4.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            button4.Location = new Point(266, 151);
            button4.Name = "button4";
            button4.Size = new Size(89, 36);
            button4.TabIndex = 79;
            button4.Text = "確認兌換";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // label15
            // 
            label15.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label15.Location = new Point(148, 90);
            label15.Name = "label15";
            label15.Size = new Size(179, 20);
            label15.TabIndex = 77;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label16.Location = new Point(64, 90);
            label16.Name = "label16";
            label16.Size = new Size(89, 20);
            label16.TabIndex = 76;
            label16.Text = "現有點數：";
            // 
            // button1
            // 
            button1.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(626, 17);
            button1.Name = "button1";
            button1.Size = new Size(69, 36);
            button1.TabIndex = 101;
            button1.Text = "首頁";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // FormHistory
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(725, 594);
            Controls.Add(tabControl1);
            Name = "FormHistory";
            Text = "Form6";
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewRecords).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Label label4;
        private Label label3;
        private Button button4;
        private Label label15;
        private Label label16;
        private TextBox txtEmail1;
        private Label label5;
        private Label label2;
        private Label label1;
        private Label label6;
        private Label label17;
        private Label label7;
        private Button btnSearch;
        private DataGridView dataGridViewRecords;
        private Label label8;
        private ListBox lstExchangeRecord;
        private ComboBox comboBoxPrize;
        private Button button1;
    }
}