﻿using System.IO;
using System.Windows.Forms;
using C_Sharp_Final.Helper;

namespace C_Sharp_Final.Helper
{
    public static class JsonPathHelper
    {
        public static string GetBookPath()
        {
            return Path.Combine(Application.StartupPath, "books.json");
        }

        public static string GetUserPath()
        {
            return Path.Combine(Application.StartupPath, "User_Records.json");
        }
            
        public static string GetExchangePath()
        {
            return Path.Combine(Application.StartupPath, "exchange_records.json");
        }
    }
}
