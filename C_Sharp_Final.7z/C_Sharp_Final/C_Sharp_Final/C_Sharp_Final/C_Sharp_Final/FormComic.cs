﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using C_Sharp_Final.Models;
using C_Sharp_Final.Helper;

namespace C_Sharp_Final
{
    public partial class FormComic : Form
    {
        private List<Books> books;
        private FormBorrow borrowForm;
        public FormComic()
        {
            InitializeComponent();
        }

        private void comBclass_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectNbMbform = comBclass.SelectedItem.ToString();
            switch (selectNbMbform)
            {
                case "漫畫":
                    FormComic mbpage = new FormComic();
                    mbpage.Show();
                    this.Hide();
                    break;
                case "小說":
                    FormNovel nbpage = new FormNovel();
                    nbpage.Show();
                    this.Hide();
                    break;
            }
        }

        private void FormComic_Load(object sender, EventArgs e)
        {
            btnMb1.Tag = 11;
            btnMb1.Click += HandleBookButtonClick;
            btnMb2.Tag = 12;
            btnMb2.Click += HandleBookButtonClick;
            btnMb3.Tag = 13;
            btnMb3.Click += HandleBookButtonClick;
            btnMb4.Tag = 14;
            btnMb4.Click += HandleBookButtonClick;

            books = BookDataHelp.Loadbooks();

            foreach (var book in books)
            {
                // 透過 Id 或書名找對應的按鈕
                Button btn = GetBtnImageByBookId(book.Id); // 你要自己建立這個方法

                if (btn != null)
                {
                    btn.Text = "";
                    Image img = Image.FromFile(book.Image);
                    if (book.isBorrowed == true)
                    {
                        btn.Image = FormBorrow.BookImageCray((Bitmap)img); // 將圖轉為灰階
                    }
                    else
                        btn.Image = img; // 顯示原圖

                    btn.ImageAlign = ContentAlignment.MiddleCenter; //對齊圖片
                }
            }
        }
        private void HandleBookButtonClick(object sender, EventArgs e)
        {
            Button btn = sender as Button;

            if (btn?.Tag == null) return;

            int bookId = Convert.ToInt32(btn.Tag);
            var book = books.FirstOrDefault(b => b.Id == bookId);

            if (book == null)
            {
                MessageBox.Show("找不到此書籍資料。");
                return;
            }

            if (borrowForm == null || borrowForm.IsDisposed)
                borrowForm = new FormBorrow();

            borrowForm.SetMbLblText(book.BookName, book.Author, book.Year.ToString(), book.Id);
            borrowForm.Show();
            this.Hide(); // 隱藏當前表單
        }
        private Button GetBtnImageByBookId(int bookId)
        {
            return bookId switch
            {
                11 => btnMbI1,
                12 => btnMbI2,
                13 => btnMbI3,
                14 => btnMbI4,
                _ => null
            };
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrontPage frontPage = new FrontPage();
            frontPage.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormHistory formHistory = new FormHistory();
            formHistory.Show();
            this.Hide();
        }
    }
}
