﻿using System;
using System.Windows.Forms;
using C_Sharp_Final_Admin;
namespace C_Sharp_Final_Admin
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new FormAdmin()); // 進入後台管理畫面
        }
    }
}
